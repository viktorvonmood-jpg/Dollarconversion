import { useQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState, type ReactNode } from "react";
import { AppHeader } from "@/components/app-header";
import { MatchCard } from "@/components/match-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { MARKET_META } from "@/lib/football/leagues";
import { loadBoard } from "@/lib/football/functions";
import { formatKickoff, formatPct, leanScore } from "@/lib/football/math";
import type { MarketKey, PredictedMatch } from "@/lib/football/types";
import { useSlip } from "@/lib/slip/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const board = useQuery({
    queryKey: ["board"],
    queryFn: () => loadBoard(),
  });
  const [league, setLeague] = useState("all");
  const [market, setMarket] = useState<"all" | MarketKey>("all");
  const [view, setView] = useState<"board" | "pulse">("board");

  const matches = board.data?.matches ?? [];
  const filtered = useMemo(() => {
    return matches.filter((m) => (league === "all" ? true : m.league === league));
  }, [matches, league]);

  const grouped = useMemo(() => {
    const map = new Map<string, PredictedMatch[]>();
    for (const match of filtered) {
      const group = formatKickoff(match.kickoff).group;
      const list = map.get(group) ?? [];
      list.push(match);
      map.set(group, list);
    }
    return [...map.entries()];
  }, [filtered]);

  const pulse = useMemo(() => {
    const rows: { match: PredictedMatch; key: MarketKey }[] = [];
    for (const match of filtered) {
      const picks = market === "all" ? match.markets : match.markets.filter((p) => p.key === market);
      const best = [...picks].sort(
        (a, b) =>
          leanScore(b.key, b.probability, b.confidence, b.edge) -
          leanScore(a.key, a.probability, a.confidence, a.edge),
      )[0];
      if (best) rows.push({ match, key: best.key });
    }
    rows.sort((a, b) => {
      const pa = a.match.markets.find((m) => m.key === a.key)!;
      const pb = b.match.markets.find((m) => m.key === b.key)!;
      return (
        leanScore(pb.key, pb.probability, pb.confidence, pb.edge) -
        leanScore(pa.key, pa.probability, pa.confidence, pa.edge)
      );
    });
    return rows.slice(0, 20);
  }, [filtered, market]);

  return (
    <div className="min-h-dvh bg-background">
      <AppHeader />
      <main className="mx-auto max-w-6xl px-4 pb-24 sm:px-6">
        <section className="relative overflow-hidden pt-8 pb-6 sm:pt-12">
          <div className="pitch-grid pointer-events-none absolute inset-0 opacity-40" />
          <div className="relative">
            <p className="text-[11px] tracking-[0.22em] text-muted-foreground uppercase">
              Live fixtures · model desk
            </p>
            <h1 className="mt-2 max-w-2xl font-display text-4xl leading-[1.05] tracking-tight sm:text-5xl">
              Football markets, priced from the table and the tape.
            </h1>
            <p className="mt-4 max-w-xl text-sm leading-relaxed text-muted-foreground sm:text-base">
              Double chance, Over 1.5, Over 2.5 / 2.6 (three goals or more), total corners, total cards, shots on
              target, and hitting the crossbar. Poisson goals plus league priors — not a tipster shout.
            </p>
          </div>
        </section>

        <div className="sticky top-16 z-30 -mx-4 mb-6 border-y border-border bg-background/90 px-4 py-3 backdrop-blur-sm sm:mx-0 sm:rounded-lg sm:border sm:px-3">
          <div className="flex flex-col gap-3">
            <div className="flex gap-2">
              <FilterButton active={view === "board"} onClick={() => setView("board")}>
                Board
              </FilterButton>
              <FilterButton active={view === "pulse"} onClick={() => setView("pulse")}>
                Strong leans
              </FilterButton>
            </div>
            <ChipRow>
              <FilterButton active={league === "all"} onClick={() => setLeague("all")}>
                All leagues
              </FilterButton>
              {(board.data?.leagues ?? []).map((item) => (
                <FilterButton
                  key={item.id}
                  active={league === item.id}
                  onClick={() => setLeague(item.id)}
                >
                  {item.short}
                  <span className="tabular-nums text-muted-foreground">{item.count}</span>
                </FilterButton>
              ))}
            </ChipRow>
            <ChipRow>
              <FilterButton active={market === "all"} onClick={() => setMarket("all")}>
                All markets
              </FilterButton>
              {MARKET_META.map((item) => (
                <FilterButton
                  key={item.key}
                  active={market === item.key}
                  onClick={() => setMarket(item.key)}
                >
                  {item.short}
                </FilterButton>
              ))}
            </ChipRow>
          </div>
        </div>

        {board.isLoading ? <BoardSkeleton /> : null}

        {board.data?.error && !matches.length ? (
          <div className="rounded-xl border border-border bg-card p-8 text-center">
            <p className="font-display text-2xl">No board yet</p>
            <p className="mt-2 text-sm text-muted-foreground">{board.data.error}</p>
            <Button className="mt-4" onClick={() => board.refetch()}>
              Retry
            </Button>
          </div>
        ) : null}

        {view === "board" && grouped.length > 0 ? (
          <div className="flex flex-col gap-10">
            {grouped.map(([label, list]) => (
              <section key={label}>
                <h2 className="mb-4 font-display text-2xl tracking-tight">{label}</h2>
                <div className="grid gap-4 lg:grid-cols-2">
                  {list.map((match, i) => (
                    <MarketFilteredCard
                      key={`${match.league}-${match.id}`}
                      match={match}
                      market={market}
                      delay={Math.min(i, 8) * 40}
                    />
                  ))}
                </div>
              </section>
            ))}
          </div>
        ) : null}

        {view === "pulse" ? <PulseList rows={pulse} /> : null}

        {!board.isLoading && !filtered.length && !board.data?.error ? (
          <p className="py-16 text-center text-sm text-muted-foreground">No fixtures in this filter.</p>
        ) : null}

        <footer className="mt-16 border-t border-border py-8 text-xs leading-relaxed text-muted-foreground">
          <p>
            Crossbar is a statistical desk, not a bookmaker. Expected goals use a Poisson model from standings,
            form and league scoring rates. Corners, cards, shots and woodwork are count models around those
            league priors. Predictions are for information only — never stake more than you can afford to lose.
          </p>
        </footer>
      </main>
    </div>
  );
}

function MarketFilteredCard({
  match,
  market,
  delay,
}: {
  match: PredictedMatch;
  market: "all" | MarketKey;
  delay: number;
}) {
  if (market === "all") return <MatchCard match={match} delay={delay} />;
  const narrowed: PredictedMatch = {
    ...match,
    markets: match.markets.filter((p) => p.key === market),
    topPick: match.markets.find((p) => p.key === market) ?? match.topPick,
  };
  return <MatchCard match={narrowed} delay={delay} />;
}

function PulseList({ rows }: { rows: { match: PredictedMatch; key: MarketKey }[] }) {
  const add = useSlip((s) => s.add);
  if (!rows.length) {
    return (
      <p className="py-16 text-center text-sm text-muted-foreground">
        No high-confidence leans in this cut. Open the board or widen the filter.
      </p>
    );
  }
  return (
    <div className="overflow-hidden rounded-xl border border-border">
      {rows.map(({ match, key }) => {
        const pick = match.markets.find((m) => m.key === key);
        if (!pick) return null;
        const when = formatKickoff(match.kickoff);
        return (
          <div
            key={`${match.id}-${key}`}
            className="flex flex-col gap-2 border-b border-border px-4 py-3 last:border-b-0 sm:flex-row sm:items-center sm:gap-4"
          >
            <div className="min-w-0 flex-1">
              <p className="text-[11px] tracking-wide text-muted-foreground uppercase">
                {match.leagueShort} · {when.day} {when.time}
              </p>
              <p className="truncate font-medium">
                {match.home.shortName} v {match.away.shortName}
              </p>
            </div>
            <div className="flex min-w-0 flex-1 items-center justify-between gap-3 sm:max-w-sm">
              <div className="min-w-0">
                <p className="text-[11px] text-muted-foreground uppercase">{pick.title}</p>
                <p className="truncate text-sm">{pick.pick}</p>
              </div>
              <Badge variant="lean" className="tabular-nums">
                {formatPct(pick.probability)}
              </Badge>
            </div>
            <Button size="sm" variant="outline" onClick={() => add(match, pick)}>
              Add
            </Button>
          </div>
        );
      })}
    </div>
  );
}

function ChipRow({ children }: { children: ReactNode }) {
  return (
    <div className="flex gap-2 overflow-x-auto pb-1 sm:flex-wrap sm:overflow-visible [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
      {children}
    </div>
  );
}

function FilterButton({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "inline-flex h-10 shrink-0 items-center gap-1.5 rounded-full border px-3 text-xs font-medium transition-colors",
        active
          ? "border-primary bg-primary text-primary-foreground"
          : "border-border bg-transparent text-muted-foreground hover:text-foreground",
      )}
    >
      {children}
    </button>
  );
}

function BoardSkeleton() {
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      {Array.from({ length: 6 }).map((_, i) => (
        <div key={i} className="rounded-xl border border-border bg-card p-5">
          <Skeleton className="h-3 w-32" />
          <div className="mt-4 flex items-center justify-between">
            <Skeleton className="size-11 rounded-full" />
            <Skeleton className="h-4 w-16" />
            <Skeleton className="size-11 rounded-full" />
          </div>
          <Skeleton className="mt-6 h-16 w-full" />
          <div className="mt-3 grid grid-cols-2 gap-2">
            <Skeleton className="h-14" />
            <Skeleton className="h-14" />
            <Skeleton className="h-14" />
            <Skeleton className="h-14" />
          </div>
        </div>
      ))}
    </div>
  );
}
