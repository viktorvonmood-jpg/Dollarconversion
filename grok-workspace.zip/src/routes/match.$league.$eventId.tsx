import { useMutation, useQuery } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, PenLine } from "lucide-react";
import { AppHeader } from "@/components/app-header";
import { FormRow } from "@/components/form-row";
import { MarketChip } from "@/components/market-chip";
import { OutcomeBar } from "@/components/prob-bar";
import { TeamCrest } from "@/components/team-crest";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { briefMatch, loadMatch } from "@/lib/football/functions";
import { formatKickoff, formatPct } from "@/lib/football/math";
import type { MatchDetail } from "@/lib/football/types";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/match/$league/$eventId")({
  component: MatchPage,
});

function MatchPage() {
  const { league, eventId } = Route.useParams();
  const q = useQuery({
    queryKey: ["match", league, eventId],
    queryFn: () => loadMatch({ data: { league, eventId } }),
  });

  if (q.isLoading) {
    return (
      <div className="min-h-dvh bg-background">
        <AppHeader />
        <div className="mx-auto max-w-3xl px-4 py-10">
          <Skeleton className="h-8 w-40" />
          <Skeleton className="mt-8 h-32 w-full" />
          <Skeleton className="mt-6 h-48 w-full" />
        </div>
      </div>
    );
  }

  if (!q.data) {
    return (
      <div className="min-h-dvh bg-background">
        <AppHeader />
        <div className="mx-auto max-w-3xl px-4 py-16 text-center">
          <p className="font-display text-3xl">Match not on the board</p>
          <p className="mt-2 text-sm text-muted-foreground">It may have finished, or the feed moved on.</p>
          <Button asChild className="mt-6">
            <Link to="/">Back to desk</Link>
          </Button>
        </div>
      </div>
    );
  }

  return <MatchDesk match={q.data} />;
}

function MatchDesk({ match }: { match: MatchDetail }) {
  const when = formatKickoff(match.kickoff);
  const brief = useMutation({
    mutationFn: () =>
      briefMatch({
        data: {
          title: `${match.home.name} vs ${match.away.name} · ${match.leagueName} · ${when.day} ${when.time}`,
          context: [
            `Venue: ${match.venue ?? "n/a"} (${match.city ?? ""})`,
            `Form ${match.home.abbr} ${match.home.form} (${match.home.record}${match.home.rank ? `, #${match.home.rank}` : ""})`,
            `Form ${match.away.abbr} ${match.away.form} (${match.away.record}${match.away.rank ? `, #${match.away.rank}` : ""})`,
            `Model 1X2 ${formatPct(match.probs.home)} / ${formatPct(match.probs.draw)} / ${formatPct(match.probs.away)}`,
            `xG ${match.expected.homeGoals}-${match.expected.awayGoals} (total ${match.expected.totalGoals})`,
            `O1.5 ${formatPct(match.probs.over15)} · O2.5 ${formatPct(match.probs.over25)} · O3.5 ${formatPct(match.probs.over35)}`,
            `Corners ${match.expected.corners} · Cards ${match.expected.cards} · SOT ${match.expected.sot} · Woodwork ${match.expected.woodwork}`,
            match.book
              ? `Book ML ${match.book.mlHome ?? "n/a"} / ${match.book.mlDraw ?? "n/a"} / ${match.book.mlAway ?? "n/a"} · O/U ${match.book.overUnder ?? "n/a"}`
              : "No book line on the feed.",
            ...match.markets.map(
              (m) => `${m.title}: ${m.pick} ${formatPct(m.probability)} conf ${m.confidence}`,
            ),
          ].join("\n"),
        },
      }),
  });

  return (
    <div className="min-h-dvh bg-background">
      <AppHeader />
      <main className="mx-auto max-w-3xl px-4 pt-6 pb-24 sm:px-6">
        <Link
          to="/"
          className="inline-flex h-11 items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="size-4" />
          Desk
        </Link>

        <p className="mt-6 text-xs tracking-[0.2em] text-muted-foreground uppercase">
          {match.leagueName} · {when.day} {when.time}
          {match.status === "in" ? " · Live" : ""}
        </p>

        <div className="mt-4 grid grid-cols-[1fr_auto_1fr] items-center gap-4">
          <TeamHero team={match.home} align="left" score={match.status === "in" ? match.home.score : null} />
          <div className="text-center">
            {match.status === "in" ? (
              <Badge variant="live">Live</Badge>
            ) : (
              <span className="font-display text-2xl text-muted-foreground">v</span>
            )}
          </div>
          <TeamHero team={match.away} align="right" score={match.status === "in" ? match.away.score : null} />
        </div>

        <p className="mt-4 text-center text-xs text-muted-foreground">
          {match.venue ?? "Venue TBC"}
          {match.city ? ` · ${match.city}` : ""}
        </p>

        <section className="mt-8 rounded-xl border border-border bg-card p-5">
          <h2 className="font-display text-2xl tracking-tight">1X2 shape</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Expected goals {match.expected.homeGoals}–{match.expected.awayGoals} · total {match.expected.totalGoals}
          </p>
          <div className="mt-4">
            <OutcomeBar
              home={match.probs.home}
              draw={match.probs.draw}
              away={match.probs.away}
              homeLabel={match.home.abbr}
              awayLabel={match.away.abbr}
            />
          </div>
          {match.book?.impliedHome != null ? (
            <p className="mt-3 text-xs text-muted-foreground">
              Book (devig) {formatPct(match.book.impliedHome)} / {formatPct(match.book.impliedDraw ?? 0)} /{" "}
              {formatPct(match.book.impliedAway ?? 0)}
              {match.book.overUnder != null ? ` · listed total ${match.book.overUnder}` : ""}
            </p>
          ) : null}
        </section>

        <section className="mt-6 grid grid-cols-2 gap-2 sm:grid-cols-4">
          <Stat label="xG total" value={String(match.expected.totalGoals)} />
          <Stat label="Corners" value={String(match.expected.corners)} />
          <Stat label="Cards" value={String(match.expected.cards)} />
          <Stat label="SOT / bar" value={`${match.expected.sot} / ${match.expected.woodwork}`} />
        </section>

        <section className="mt-8">
          <h2 className="font-display text-2xl tracking-tight">Market sheet</h2>
          <p className="mt-1 mb-4 text-sm text-muted-foreground">
            Add a pick to the slip. Fair odds are 1 / model probability.
          </p>
          <div className="flex flex-col gap-2">
            {match.markets.map((pick) => (
              <div key={pick.key} className="rounded-lg border border-border bg-card p-3">
                <MarketChip match={match} pick={pick} />
                <p className="mt-2 text-xs leading-relaxed text-muted-foreground">{pick.rationale}</p>
                <p className="mt-1 text-xs text-muted-foreground tabular-nums">
                  Fair {pick.fairOdds.toFixed(2)}
                  {pick.edge != null
                    ? ` · edge ${pick.edge > 0 ? "+" : ""}${Math.round(pick.edge * 100)} pts`
                    : ""}
                  {` · confidence ${pick.confidence}`}
                </p>
              </div>
            ))}
          </div>
        </section>

        <section className="mt-8 grid gap-4 sm:grid-cols-2">
          <RecentCard name={match.home.shortName} recents={match.recents.home} />
          <RecentCard name={match.away.shortName} recents={match.recents.away} />
        </section>

        <section className="mt-8 rounded-xl border border-border bg-card p-5">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h2 className="font-display text-2xl tracking-tight">Desk note</h2>
              <p className="mt-1 text-sm text-muted-foreground">
                Optional analyst write-up from the same sheet. One request per read.
              </p>
            </div>
            <Button size="sm" variant="outline" disabled={brief.isPending} onClick={() => brief.mutate()}>
              <PenLine />
              {brief.isPending ? "Writing" : "Ask the desk"}
            </Button>
          </div>
          <Separator className="my-4" />
          {brief.data?.ok === true ? (
            <div className="space-y-3 text-sm leading-relaxed text-foreground/90">
              {brief.data.text.split(/\n\n+/).map((para, i) => (
                <p key={i}>{para}</p>
              ))}
            </div>
          ) : brief.data && !brief.data.ok ? (
            <p className="text-sm text-muted-foreground">{brief.data.error}</p>
          ) : (
            <p className="text-sm text-muted-foreground">
              The note uses this match’s numbers only. It is not a bet recommendation.
            </p>
          )}
        </section>
      </main>
    </div>
  );
}

function TeamHero({
  team,
  align,
  score,
}: {
  team: MatchDetail["home"];
  align: "left" | "right";
  score: number | null;
}) {
  return (
    <div className={cn("flex min-w-0 items-center gap-3", align === "right" && "flex-row-reverse")}>
      <TeamCrest src={team.logo} name={team.abbr} color={team.color} size="lg" />
      <div className={cn("min-w-0", align === "right" && "text-right")}>
        <p className="truncate font-display text-2xl leading-tight tracking-tight sm:text-3xl">
          {team.shortName}
        </p>
        <div className={cn("mt-1 flex items-center gap-2", align === "right" && "flex-row-reverse")}>
          {score != null ? (
            <span className="font-display text-3xl tabular-nums">{score}</span>
          ) : (
            <span className="text-xs text-muted-foreground tabular-nums">{team.record}</span>
          )}
          <FormRow form={team.form} />
        </div>
        {team.rank ? (
          <p className="mt-1 text-xs tracking-wide text-muted-foreground uppercase">
            {team.rank === 1 ? "1st" : team.rank === 2 ? "2nd" : team.rank === 3 ? "3rd" : `${team.rank}th`}
            {team.pts ? ` · ${team.pts} pts` : ""}
          </p>
        ) : null}
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-border bg-card px-3 py-3">
      <p className="text-xs tracking-wide text-muted-foreground uppercase">{label}</p>
      <p className="font-display text-2xl tabular-nums">{value}</p>
    </div>
  );
}

function RecentCard({
  name,
  recents,
}: {
  name: string;
  recents: MatchDetail["recents"]["home"];
}) {
  return (
    <div className="rounded-xl border border-border bg-card p-4">
      <h3 className="text-sm font-medium">{name} · last five</h3>
      {recents.length === 0 ? (
        <p className="mt-3 text-xs text-muted-foreground">No recent sheet on the feed.</p>
      ) : (
        <ul className="mt-3 flex flex-col gap-2">
          {recents.map((row, i) => (
            <li key={`${row.date}-${i}`} className="flex items-center justify-between gap-2 text-sm">
              <span className="min-w-0 truncate text-muted-foreground">
                {row.atHome ? "vs" : "@"} {row.opponentAbbr}
              </span>
              <span className="flex items-center gap-2">
                <span className="tabular-nums">{row.score}</span>
                <span
                  className={cn(
                    "inline-flex size-5 items-center justify-center rounded-xs text-xs font-semibold",
                    row.result === "W" && "bg-lean/20 text-lean",
                    row.result === "D" && "bg-secondary text-muted-foreground",
                    row.result === "L" && "bg-live/15 text-live",
                  )}
                >
                  {row.result}
                </span>
              </span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
