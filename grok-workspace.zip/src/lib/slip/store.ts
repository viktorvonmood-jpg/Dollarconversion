import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { MarketPick, PredictedMatch } from "@/lib/football/types";

export type SlipLeg = {
  id: string;
  matchId: string;
  league: string;
  kickoff: string;
  home: string;
  away: string;
  homeAbbr: string;
  awayAbbr: string;
  marketKey: MarketPick["key"];
  title: string;
  pick: string;
  probability: number;
  fairOdds: number;
};

type SlipState = {
  legs: SlipLeg[];
  open: boolean;
  setOpen: (open: boolean) => void;
  add: (match: PredictedMatch, pick: MarketPick) => void;
  remove: (id: string) => void;
  clear: () => void;
};

export function combinedProbability(legs: SlipLeg[]): number {
  if (!legs.length) return 0;
  return legs.reduce((acc, leg) => acc * leg.probability, 1);
}

export function combinedOdds(legs: SlipLeg[]): number {
  const p = combinedProbability(legs);
  if (p <= 0) return 0;
  return Math.round((1 / p) * 100) / 100;
}

export const useSlip = create<SlipState>()(
  persist(
    (set, get) => ({
      legs: [],
      open: false,
      setOpen: (open) => set({ open }),
      add: (match, pick) => {
        const id = `${match.league}:${match.id}:${pick.key}`;
        const existing = get().legs.filter((leg) => !(leg.matchId === match.id && leg.marketKey === pick.key));
        const next: SlipLeg = {
          id,
          matchId: match.id,
          league: match.league,
          kickoff: match.kickoff,
          home: match.home.shortName,
          away: match.away.shortName,
          homeAbbr: match.home.abbr,
          awayAbbr: match.away.abbr,
          marketKey: pick.key,
          title: pick.title,
          pick: pick.pick,
          probability: pick.probability,
          fairOdds: pick.fairOdds,
        };
        set({ legs: [...existing, next].slice(-8), open: true });
      },
      remove: (id) => set({ legs: get().legs.filter((leg) => leg.id !== id) }),
      clear: () => set({ legs: [] }),
    }),
    { name: "crossbar-slip" },
  ),
);
