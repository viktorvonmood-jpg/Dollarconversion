import { LEAGUES, LEAGUE_BY_SLUG } from "./leagues";
import { parseAmerican } from "./math";
import { impliedFromBook, predictMatch, type ModelInput } from "./model";
import type {
  BoardPayload,
  BookSnapshot,
  LeagueCount,
  MatchDetail,
  PredictedMatch,
  RatingTable,
  RecentResult,
  TeamRating,
  TeamSide,
} from "./types";

const UA = "Mozilla/5.0 (compatible; CrossbarPredictions/1.0)";
const TTL_MS = 7 * 60 * 1000;
const cache = new Map<string, { at: number; data: unknown }>();

function readCache<T>(key: string): T | null {
  const hit = cache.get(key);
  if (!hit) return null;
  if (Date.now() - hit.at > TTL_MS) {
    cache.delete(key);
    return null;
  }
  return hit.data as T;
}

function writeCache(key: string, data: unknown) {
  cache.set(key, { at: Date.now(), data });
}

async function espnJson(url: string): Promise<unknown | null> {
  const cached = readCache<unknown>(`espn:${url}`);
  if (cached) return cached;
  try {
    const res = await fetch(url, {
      headers: { "User-Agent": UA, Accept: "application/json" },
      signal: AbortSignal.timeout(9000),
    });
    if (!res.ok) return null;
    const json = await res.json();
    writeCache(`espn:${url}`, json);
    return json;
  } catch {
    return null;
  }
}

function asRecord(value: unknown): Record<string, unknown> | null {
  return value !== null && typeof value === "object" ? (value as Record<string, unknown>) : null;
}

function asArray(value: unknown): unknown[] {
  return Array.isArray(value) ? value : [];
}

function str(value: unknown, fallback = ""): string {
  return typeof value === "string" ? value : fallback;
}

function num(value: unknown, fallback = 0): number {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string") {
    const n = Number(value);
    if (Number.isFinite(n)) return n;
  }
  return fallback;
}

function statusFrom(raw: unknown): { status: ModelInput["status"]; detail: string } {
  const type = asRecord(asRecord(raw)?.type);
  const state = str(type?.state, "pre");
  const status = state === "in" || state === "post" ? state : "pre";
  return { status, detail: str(type?.shortDetail) || str(type?.description) || "Scheduled" };
}

function parseOdds(competition: Record<string, unknown>): BookSnapshot | null {
  const first = asRecord(asArray(competition.odds)[0]);
  if (!first) return null;
  const ml = asRecord(first.moneyline);
  const home = asRecord(asRecord(ml?.home)?.close) ?? asRecord(ml?.home);
  const away = asRecord(asRecord(ml?.away)?.close) ?? asRecord(ml?.away);
  const draw = asRecord(asRecord(ml?.draw)?.close) ?? asRecord(ml?.draw);
  const total = asRecord(first.total);
  const over = asRecord(asRecord(asRecord(total?.over)?.close) ?? asRecord(total?.over));
  const under = asRecord(asRecord(asRecord(total?.under)?.close) ?? asRecord(total?.under));
  const snapshot: BookSnapshot = {
    mlHome: parseAmerican(home?.odds),
    mlDraw: parseAmerican(draw?.odds),
    mlAway: parseAmerican(away?.odds),
    overUnder: num(first.overUnder, NaN),
    overOdds: parseAmerican(over?.odds),
    underOdds: parseAmerican(under?.odds),
    impliedHome: null,
    impliedDraw: null,
    impliedAway: null,
    impliedOver: null,
    impliedUnder: null,
  };
  if (Number.isNaN(snapshot.overUnder as number)) snapshot.overUnder = null;
  if (
    snapshot.mlHome == null &&
    snapshot.mlAway == null &&
    snapshot.overUnder == null
  ) {
    return null;
  }
  return impliedFromBook(snapshot);
}

function parseTeam(comp: Record<string, unknown>, homeAway: "home" | "away"): TeamSide | null {
  const team = asRecord(comp.team);
  if (!team) return null;
  const records = asArray(comp.records);
  const rec0 = asRecord(records[0]);
  const color = str(team.color, "3f4550").replace("#", "");
  const alt = str(team.alternateColor, "d0d4da").replace("#", "");
  const logo = str(team.logo) || `https://a.espncdn.com/i/teamlogos/soccer/500/${str(team.id)}.png`;
  return {
    id: str(team.id),
    name: str(team.displayName, "Team"),
    shortName: str(team.shortDisplayName) || str(team.name) || str(team.displayName, "Team"),
    abbr: str(team.abbreviation, "FC"),
    logo,
    color,
    altColor: alt,
    form: str(comp.form).toUpperCase(),
    record: str(rec0?.summary, "0-0-0"),
    rank: null,
    gp: 0,
    gf: 0,
    ga: 0,
    pts: 0,
    homeAway,
    score: comp.score == null || comp.score === "" ? null : num(comp.score, 0),
  };
}

function parseEvent(event: Record<string, unknown>, leagueSlug: string): ModelInput | null {
  const profile = LEAGUE_BY_SLUG[leagueSlug];
  const competitions = asArray(event.competitions);
  const competition = asRecord(competitions[0]) ?? event;
  const competitors = asArray(asRecord(competition)?.competitors ?? event.competitions);
  const list = asArray(asRecord(competition)?.competitors);
  if (list.length < 2) return null;
  let homeRaw: Record<string, unknown> | null = null;
  let awayRaw: Record<string, unknown> | null = null;
  for (const item of list) {
    const rec = asRecord(item);
    if (!rec) continue;
    if (str(rec.homeAway) === "home") homeRaw = rec;
    if (str(rec.homeAway) === "away") awayRaw = rec;
  }
  if (!homeRaw || !awayRaw) {
    homeRaw = asRecord(list[0]);
    awayRaw = asRecord(list[1]);
  }
  if (!homeRaw || !awayRaw) return null;
  const home = parseTeam(homeRaw, "home");
  const away = parseTeam(awayRaw, "away");
  if (!home || !away) return null;
  const venue =
    asRecord(asRecord(competition)?.venue) ?? asRecord(event.venue);
  const address = asRecord(venue?.address);
  const { status, detail } = statusFrom(event.status ?? asRecord(competition)?.status);
  return {
    id: str(event.id),
    league: leagueSlug,
    leagueName: profile?.name ?? str(event.name, leagueSlug),
    leagueShort: profile?.short ?? leagueSlug,
    kickoff: str(event.date),
    venue: str(venue?.fullName) || null,
    city: str(address?.city) || null,
    status,
    statusDetail: detail,
    home,
    away,
    book: parseOdds(asRecord(competition) ?? {}),
  };
}

function statValue(stats: unknown[], name: string): number {
  for (const item of stats) {
    const rec = asRecord(item);
    if (str(rec?.name) === name || str(rec?.abbreviation) === name) {
      return num(rec?.value, 0);
    }
  }
  return 0;
}

function parseStandings(json: unknown): RatingTable | null {
  const root = asRecord(json);
  if (!root) return null;
  const children = asArray(root.children);
  const groups = children.length ? children : [root];
  const byId: Record<string, TeamRating> = {};
  let gfSum = 0;
  let gpSum = 0;
  for (const group of groups) {
    const g = asRecord(group);
    const entries = asArray(asRecord(asRecord(g?.standings)?.standings)?.entries).length
      ? asArray(asRecord(asRecord(g?.standings)?.standings)?.entries)
      : asArray(asRecord(g?.standings)?.entries);
    const fallback = entries.length ? entries : asArray(asRecord(g?.standings)?.entries);
    const list = fallback.length ? fallback : asArray(asRecord(g)?.entries);
    for (const entry of list.length ? list : entries) {
      const rec = asRecord(entry);
      if (!rec) continue;
      const team = asRecord(rec.team);
      const id = str(team?.id);
      if (!id) continue;
      const stats = asArray(rec.stats);
      const gp = statValue(stats, "gamesPlayed") || statValue(stats, "GP");
      const gf = statValue(stats, "pointsFor") || statValue(stats, "GF");
      const ga = statValue(stats, "pointsAgainst") || statValue(stats, "GA");
      const pts = statValue(stats, "points") || statValue(stats, "PTS");
      const rank = statValue(stats, "rank") || 0;
      gfSum += gf;
      gpSum += gp;
      byId[id] = {
        teamId: id,
        gp,
        gf,
        ga,
        pts,
        rank,
        attack: 1,
        defense: 1,
      };
    }
  }
  const ids = Object.keys(byId);
  if (!ids.length) return null;
  const avgFor = gpSum > 0 ? gfSum / gpSum : 1.35;
  for (const id of ids) {
    const row = byId[id]!;
    const gp = Math.max(row.gp, 1);
    row.attack = row.gf / gp / Math.max(avgFor, 0.6);
    row.defense = row.ga / gp / Math.max(avgFor, 0.6);
  }
  return { byId, avgGoals: avgFor * 2 };
}

function applyRatings(input: ModelInput, table: RatingTable | null): ModelInput {
  if (!table) return input;
  const patch = (team: TeamSide): TeamSide => {
    const row = table.byId[team.id];
    if (!row) return team;
    return {
      ...team,
      rank: row.rank || team.rank,
      gp: row.gp || team.gp,
      gf: row.gf || team.gf,
      ga: row.ga || team.ga,
      pts: row.pts || team.pts,
    };
  };
  return { ...input, home: patch(input.home), away: patch(input.away) };
}

async function fetchScoreboard(slug: string): Promise<ModelInput[]> {
  const json = await espnJson(
    `https://site.api.espn.com/apis/site/v2/sports/soccer/${slug}/scoreboard`,
  );
  const root = asRecord(json);
  if (!root) return [];
  const events = asArray(root.events);
  const parsed: ModelInput[] = [];
  for (const event of events) {
    const rec = asRecord(event);
    if (!rec) continue;
    const item = parseEvent(rec, slug);
    if (item) parsed.push(item);
  }
  return parsed;
}

async function fetchRatings(slug: string): Promise<RatingTable | null> {
  const profile = LEAGUE_BY_SLUG[slug];
  if (!profile?.standings) return null;
  const json = await espnJson(
    `https://site.api.espn.com/apis/v2/sports/soccer/${slug}/standings`,
  );
  return parseStandings(json);
}

function parseRecents(json: unknown, teamId: string): RecentResult[] {
  const rows = asArray(json);
  const mine = rows.find((row) => str(asRecord(asRecord(row)?.team)?.id) === teamId);
  const events = asArray(asRecord(mine)?.events);
  const out: RecentResult[] = [];
  for (const event of events.slice(0, 5)) {
    const rec = asRecord(event);
    if (!rec) continue;
    const opp = asRecord(rec.opponent);
    const resultRaw = str(rec.gameResult, "D").toUpperCase();
    const result: RecentResult["result"] =
      resultRaw === "W" || resultRaw === "L" ? resultRaw : "D";
    out.push({
      opponent: str(opp?.displayName, "Opponent"),
      opponentAbbr: str(opp?.abbreviation, "OPP"),
      result,
      score: str(rec.score, "–"),
      atHome: str(rec.atVs) === "vs",
      date: str(rec.gameDate),
      competition: str(rec.leagueAbbreviation) || str(rec.competitionName),
    });
  }
  return out;
}

export async function fetchBoard(): Promise<BoardPayload> {
  const generatedAt = new Date().toISOString();
  try {
    const scoreboards = await Promise.all(LEAGUES.map((league) => fetchScoreboard(league.slug)));
    const ratingList = await Promise.all(LEAGUES.map((league) => fetchRatings(league.slug)));
    const ratingsByLeague: Record<string, RatingTable | null> = {};
    LEAGUES.forEach((league, i) => {
      ratingsByLeague[league.slug] = ratingList[i] ?? null;
    });

    const matches: PredictedMatch[] = [];
    for (let i = 0; i < LEAGUES.length; i += 1) {
      const league = LEAGUES[i]!;
      const table = ratingsByLeague[league.slug] ?? null;
      for (const event of scoreboards[i] ?? []) {
        if (event.status === "post") continue;
        matches.push(predictMatch(applyRatings(event, table), table));
      }
    }

    matches.sort((a, b) => {
      if (a.status === "in" && b.status !== "in") return -1;
      if (b.status === "in" && a.status !== "in") return 1;
      return new Date(a.kickoff).getTime() - new Date(b.kickoff).getTime();
    });

    const leagues: LeagueCount[] = LEAGUES.map((league, i) => ({
      id: league.slug,
      name: league.name,
      short: league.short,
      count: (scoreboards[i] ?? []).filter((e) => e.status !== "post").length,
    })).filter((l) => l.count > 0);

    return {
      generatedAt,
      matches,
      leagues,
      error: matches.length ? null : "No upcoming fixtures found. Try again shortly.",
    };
  } catch (err) {
    return {
      generatedAt,
      matches: [],
      leagues: [],
      error: err instanceof Error ? err.message : "Could not load fixtures.",
    };
  }
}

export async function fetchMatchDetail(
  league: string,
  eventId: string,
): Promise<MatchDetail | null> {
  const board = await fetchBoard();
  const found = board.matches.find((m) => m.id === eventId && m.league === league);
  const summary = await espnJson(
    `https://site.api.espn.com/apis/site/v2/sports/soccer/${league}/summary?event=${eventId}`,
  );
  const recentsHome = found ? parseRecents(asRecord(summary)?.lastFiveGames, found.home.id) : [];
  const recentsAway = found ? parseRecents(asRecord(summary)?.lastFiveGames, found.away.id) : [];

  if (found) {
    return { ...found, recents: { home: recentsHome, away: recentsAway } };
  }

  const header = asRecord(asRecord(summary)?.header);
  if (!header) return null;
  const parsed = parseEvent(header, league);
  if (!parsed) return null;
  const table = await fetchRatings(league);
  const predicted = predictMatch(applyRatings(parsed, table), table);
  return {
    ...predicted,
    recents: {
      home: parseRecents(asRecord(summary)?.lastFiveGames, predicted.home.id),
      away: parseRecents(asRecord(summary)?.lastFiveGames, predicted.away.id),
    },
  };
}
