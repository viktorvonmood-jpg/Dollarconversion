export type MatchStatus = "pre" | "in" | "post";

export type MarketKey =
  | "double_chance"
  | "over_15"
  | "over_25"
  | "corners"
  | "cards"
  | "sot"
  | "woodwork";

export type TeamSide = {
  id: string;
  name: string;
  shortName: string;
  abbr: string;
  logo: string;
  color: string;
  altColor: string;
  form: string;
  record: string;
  rank: number | null;
  gp: number;
  gf: number;
  ga: number;
  pts: number;
  homeAway: "home" | "away";
  score: number | null;
};

export type BookSnapshot = {
  mlHome: number | null;
  mlDraw: number | null;
  mlAway: number | null;
  overUnder: number | null;
  overOdds: number | null;
  underOdds: number | null;
  impliedHome: number | null;
  impliedDraw: number | null;
  impliedAway: number | null;
  impliedOver: number | null;
  impliedUnder: number | null;
};

export type MarketPick = {
  key: MarketKey;
  title: string;
  pick: string;
  line: number | null;
  probability: number;
  fairOdds: number;
  bookImplied: number | null;
  edge: number | null;
  confidence: number;
  rationale: string;
};

export type ExpectedSheet = {
  homeGoals: number;
  awayGoals: number;
  totalGoals: number;
  corners: number;
  cards: number;
  sot: number;
  woodwork: number;
};

export type OutcomeProbs = {
  home: number;
  draw: number;
  away: number;
  over15: number;
  over25: number;
  over35: number;
};

export type PredictedMatch = {
  id: string;
  league: string;
  leagueName: string;
  leagueShort: string;
  kickoff: string;
  venue: string | null;
  city: string | null;
  status: MatchStatus;
  statusDetail: string;
  home: TeamSide;
  away: TeamSide;
  expected: ExpectedSheet;
  probs: OutcomeProbs;
  markets: MarketPick[];
  topPick: MarketPick;
  book: BookSnapshot | null;
};

export type RecentResult = {
  opponent: string;
  opponentAbbr: string;
  result: "W" | "D" | "L";
  score: string;
  atHome: boolean;
  date: string;
  competition: string;
};

export type MatchDetail = PredictedMatch & {
  recents: { home: RecentResult[]; away: RecentResult[] };
};

export type LeagueCount = {
  id: string;
  name: string;
  short: string;
  count: number;
};

export type BoardPayload = {
  generatedAt: string;
  matches: PredictedMatch[];
  leagues: LeagueCount[];
  error: string | null;
};

export type TeamRating = {
  teamId: string;
  gp: number;
  gf: number;
  ga: number;
  pts: number;
  rank: number;
  attack: number;
  defense: number;
};

export type RatingTable = {
  byId: Record<string, TeamRating>;
  avgGoals: number;
};
