import { LEAGUE_BY_SLUG, type LeagueProfile } from "./leagues";
import {
  americanToProb,
  clamp,
  confidenceFrom,
  fairDecimal,
  leanScore,
  nearestLine,
  poissonOver,
  poissonPmf,
  round1,
  round2,
} from "./math";
import type {
  BookSnapshot,
  ExpectedSheet,
  MarketPick,
  OutcomeProbs,
  PredictedMatch,
  RatingTable,
  TeamSide,
} from "./types";

export type ModelInput = {
  id: string;
  league: string;
  leagueName: string;
  leagueShort: string;
  kickoff: string;
  venue: string | null;
  city: string | null;
  status: "pre" | "in" | "post";
  statusDetail: string;
  home: TeamSide;
  away: TeamSide;
  book: BookSnapshot | null;
};

function formScore(form: string): number {
  const chars = form.replace(/[^WDLwdl]/g, "").split("");
  if (!chars.length) return 0.45;
  let weighted = 0;
  let total = 0;
  chars.forEach((char, index) => {
    const recency = Math.pow(0.82, index);
    const value = char.toUpperCase() === "W" ? 1 : char.toUpperCase() === "D" ? 0.42 : 0;
    weighted += value * recency;
    total += recency;
  });
  return total ? weighted / total : 0.45;
}

function parseRecord(record: string): { w: number; d: number; l: number; gp: number } {
  const parts = record.split("-").map((p) => Number(p.trim()));
  const w = parts[0] || 0;
  const d = parts[1] || 0;
  const l = parts[2] || 0;
  return { w, d, l, gp: w + d + l };
}

function outcomeProbs(lh: number, la: number): OutcomeProbs {
  const max = 10;
  let home = 0;
  let draw = 0;
  let away = 0;
  let over15 = 0;
  let over25 = 0;
  let over35 = 0;
  for (let i = 0; i <= max; i += 1) {
    const pi = poissonPmf(i, lh);
    for (let j = 0; j <= max; j += 1) {
      const p = pi * poissonPmf(j, la);
      if (i > j) home += p;
      else if (i === j) draw += p;
      else away += p;
      const total = i + j;
      if (total >= 2) over15 += p;
      if (total >= 3) over25 += p;
      if (total >= 4) over35 += p;
    }
  }
  const s = home + draw + away;
  return {
    home: home / s,
    draw: draw / s,
    away: away / s,
    over15,
    over25,
    over35,
  };
}

function strengthFor(
  team: TeamSide,
  table: RatingTable | null,
  leagueAvg: number,
): { attack: number; defense: number; sample: number } {
  const rated = table?.byId[team.id];
  if (rated && rated.gp >= 2) {
    return {
      attack: clamp(rated.attack, 0.45, 1.85),
      defense: clamp(rated.defense, 0.45, 1.85),
      sample: rated.gp,
    };
  }
  const rec = parseRecord(team.record);
  const gp = rec.gp || team.gp || 4;
  const gf = team.gf || rec.w * 1.7 + rec.d * 1.05 + rec.l * 0.55;
  const ga = team.ga || rec.l * 1.65 + rec.d * 1.05 + rec.w * 0.55;
  const attack = clamp(gf / Math.max(gp, 1) / Math.max(leagueAvg / 2, 0.8), 0.5, 1.8);
  const defense = clamp(ga / Math.max(gp, 1) / Math.max(leagueAvg / 2, 0.8), 0.5, 1.8);
  return { attack, defense, sample: gp };
}

function pickCountMarket(
  key: MarketPick["key"],
  title: string,
  expected: number,
  lines: number[],
  sample: number,
  rationaleBase: string,
  bookImpliedOver: number | null,
  bookLine: number | null,
): MarketPick {
  const line = nearestLine(expected, lines);
  const overP = clamp(poissonOver(line, expected), 0.08, 0.94);
  const useOver = overP >= 0.5;
  const probability = useOver ? overP : 1 - overP;
  const implied =
    bookLine != null && Math.abs(bookLine - line) < 0.2 ? bookImpliedOver : null;
  const bookForSide =
    implied == null ? null : useOver ? implied : 1 - implied;
  const edge = bookForSide == null ? null : round2(probability - bookForSide);
  return {
    key,
    title,
    pick: `${useOver ? "Over" : "Under"} ${line}`,
    line,
    probability,
    fairOdds: fairDecimal(probability),
    bookImplied: bookForSide,
    edge,
    confidence: confidenceFrom(probability, sample, edge),
    rationale: `${rationaleBase} Model expects ${round1(expected)}. ${useOver ? "Over" : "Under"} ${line} at ${Math.round(probability * 100)}%.`,
  };
}

function doubleChance(
  probs: OutcomeProbs,
  home: TeamSide,
  away: TeamSide,
  sample: number,
  book: BookSnapshot | null,
): MarketPick {
  const oneX = probs.home + probs.draw;
  const xTwo = probs.away + probs.draw;
  const twelve = probs.home + probs.away;
  const options: { pick: string; p: number; why: string }[] = [
    {
      pick: `1X ${home.abbr}`,
      p: oneX,
      why: `${home.shortName} not to lose`,
    },
    {
      pick: `X2 ${away.abbr}`,
      p: xTwo,
      why: `${away.shortName} not to lose`,
    },
    {
      pick: "1X2 no draw (12)",
      p: twelve,
      why: "Match to have a winner",
    },
  ];

  // Prefer 1X / X2 unless the draw is truly crushed.
  const ranked = [...options].sort((a, b) => b.p - a.p);
  const favoriteSide = probs.home >= probs.away ? options[0] : options[1];
  const chosen =
    probs.draw < 0.22 && twelve > 0.82 && Math.abs(probs.home - probs.away) < 0.12
      ? options[2]
      : favoriteSide.p >= 0.62
        ? favoriteSide
        : ranked[0]!;

  let bookImplied: number | null = null;
  if (book?.impliedHome != null && book.impliedDraw != null && book.impliedAway != null) {
    if (chosen.pick.startsWith("1X ")) bookImplied = book.impliedHome + book.impliedDraw;
    else if (chosen.pick.startsWith("X2 ")) bookImplied = book.impliedAway + book.impliedDraw;
    else bookImplied = book.impliedHome + book.impliedAway;
  }
  const edge = bookImplied == null ? null : round2(chosen.p - bookImplied);

  return {
    key: "double_chance",
    title: "Double chance",
    pick: chosen.pick,
    line: null,
    probability: chosen.p,
    fairOdds: fairDecimal(chosen.p),
    bookImplied,
    edge,
    confidence: confidenceFrom(chosen.p, sample, edge),
    rationale: `${chosen.why}. 1X ${Math.round(oneX * 100)}% · 12 ${Math.round(twelve * 100)}% · X2 ${Math.round(xTwo * 100)}%.`,
  };
}

export function predictMatch(input: ModelInput, table: RatingTable | null): PredictedMatch {
  const profile: LeagueProfile =
    LEAGUE_BY_SLUG[input.league] ?? LEAGUE_BY_SLUG["eng.1"]!;
  const leagueAvg = table?.avgGoals || profile.avgGoals;
  const homeS = strengthFor(input.home, table, leagueAvg);
  const awayS = strengthFor(input.away, table, leagueAvg);
  const homeForm = formScore(input.home.form);
  const awayForm = formScore(input.away.form);

  const homeAttack = homeS.attack * 0.74 + (0.72 + 0.55 * homeForm) * 0.26;
  const awayAttack = awayS.attack * 0.74 + (0.72 + 0.55 * awayForm) * 0.26;
  const homeDef = homeS.defense * 0.76 + (1.28 - 0.5 * homeForm) * 0.24;
  const awayDef = awayS.defense * 0.76 + (1.28 - 0.5 * awayForm) * 0.24;

  const avgHome = leagueAvg * profile.homeShare;
  const avgAway = leagueAvg * (1 - profile.homeShare);
  let homeGoals = clamp(homeAttack * awayDef * avgHome * (profile.homeAdv / 1.08), 0.35, 3.6);
  let awayGoals = clamp(awayAttack * homeDef * avgAway / (profile.homeAdv / 1.08), 0.2, 3.1);

  const probs = outcomeProbs(homeGoals, awayGoals);
  const totalGoals = homeGoals + awayGoals;
  const sample = Math.min(homeS.sample, awayS.sample);

  const mismatch = Math.abs(homeGoals - awayGoals);
  const closeness = 1 - clamp(mismatch / 1.8, 0, 1);
  const attackMean = (homeAttack + awayAttack) / 2;

  const corners = clamp(
    profile.avgCorners * (0.72 + 0.28 * attackMean) * (0.94 + 0.12 * mismatch * 0.25),
    7.2,
    14.5,
  );
  const cards = clamp(
    profile.avgCards * (0.86 + 0.28 * closeness) * (input.league.includes("bra") || input.league.includes("tur") ? 1.04 : 1),
    2.6,
    7.2,
  );
  const sot = clamp(totalGoals / 0.31, 6.2, 14.8);
  const woodwork = clamp(profile.avgWoodwork * (sot / Math.max(profile.avgSot, 8)), 0.28, 1.05);

  const expected: ExpectedSheet = {
    homeGoals: round2(homeGoals),
    awayGoals: round2(awayGoals),
    totalGoals: round2(totalGoals),
    corners: round1(corners),
    cards: round1(cards),
    sot: round1(sot),
    woodwork: round2(woodwork),
  };

  const bookOver =
    input.book?.overUnder != null && Math.abs(input.book.overUnder - 2.5) < 0.2
      ? input.book.impliedOver
      : null;

  const over15P = clamp(probs.over15, 0.12, 0.96);
  const over25P = clamp(probs.over25, 0.08, 0.9);
  const over15: MarketPick = {
    key: "over_15",
    title: "Over 1.5 goals",
    pick: over15P >= 0.5 ? "Over 1.5" : "Under 1.5",
    line: 1.5,
    probability: over15P >= 0.5 ? over15P : 1 - over15P,
    fairOdds: fairDecimal(over15P >= 0.5 ? over15P : 1 - over15P),
    bookImplied: null,
    edge: null,
    confidence: confidenceFrom(over15P >= 0.5 ? over15P : 1 - over15P, sample, null),
    rationale: `Expected goals ${expected.homeGoals}–${expected.awayGoals} (total ${expected.totalGoals}). P(2+ goals) ${Math.round(over15P * 100)}%.`,
  };

  const over25Side = over25P >= 0.5;
  const over25Prob = over25Side ? over25P : 1 - over25P;
  const over25Edge =
    bookOver == null ? null : round2((over25Side ? over25P : 1 - over25P) - (over25Side ? bookOver : 1 - bookOver));
  const over25: MarketPick = {
    key: "over_25",
    title: "Over 2.5 / 2.6",
    pick: over25Side ? "Over 2.5" : "Under 2.5",
    line: 2.5,
    probability: over25Prob,
    fairOdds: fairDecimal(over25Prob),
    bookImplied: bookOver == null ? null : over25Side ? bookOver : 1 - bookOver,
    edge: over25Edge,
    confidence: confidenceFrom(over25Prob, sample, over25Edge),
    rationale: `xG total ${expected.totalGoals}. Goals are whole numbers, so Over 2.5 and Over 2.6 are the same call: three or more. Model has ${Math.round(over25P * 100)}% on 3+ goals.`,
  };

  const woodP = clamp(poissonOver(0.5, woodwork), 0.18, 0.78);
  const woodPickOver = woodP >= 0.5;
  const woodProb = woodPickOver ? woodP : 1 - woodP;
  const woodworkM: MarketPick = {
    key: "woodwork",
    title: "Hitting the crossbar",
    pick: woodPickOver ? "Over 0.5 woodwork" : "Under 0.5 woodwork",
    line: 0.5,
    probability: woodProb,
    fairOdds: fairDecimal(woodProb),
    bookImplied: null,
    edge: null,
    confidence: confidenceFrom(woodProb, sample, null) - 6,
    rationale: `Posts + bar. Expected woodwork hits ${expected.woodwork} from ${expected.sot} shots on target. Frame events track shot volume, not finishing.`,
  };

  const dc = doubleChance(probs, input.home, input.away, sample, input.book);
  const cornersM = pickCountMarket(
    "corners",
    "Total corners",
    corners,
    [8.5, 9.5, 10.5, 11.5],
    sample,
    `${input.home.abbr} and ${input.away.abbr} generate ${round1(corners)} combined corners.`,
    null,
    null,
  );
  const cardsM = pickCountMarket(
    "cards",
    "Total cards",
    cards,
    [3.5, 4.5, 5.5],
    sample,
    `Booking climate for ${profile.short} plus match tightness.`,
    null,
    null,
  );
  const sotM = pickCountMarket(
    "sot",
    "Shots on target",
    sot,
    [7.5, 8.5, 9.5, 10.5],
    sample,
    `On-target volume from a ${expected.totalGoals} xG game.`,
    null,
    null,
  );

  const markets = [dc, over15, over25, cornersM, cardsM, sotM, woodworkM].map((m) => ({
    ...m,
    confidence: clamp(m.confidence, 36, 94),
    probability: clamp(m.probability, 0.08, 0.96),
  }));

  const topPick = [...markets].sort(
    (a, b) => leanScore(b.key, b.probability, b.confidence, b.edge) - leanScore(a.key, a.probability, a.confidence, a.edge),
  )[0]!;

  return {
    id: input.id,
    league: input.league,
    leagueName: input.leagueName,
    leagueShort: input.leagueShort,
    kickoff: input.kickoff,
    venue: input.venue,
    city: input.city,
    status: input.status,
    statusDetail: input.statusDetail,
    home: input.home,
    away: input.away,
    expected,
    probs,
    markets,
    topPick,
    book: input.book,
  };
}

export function impliedFromBook(book: BookSnapshot): BookSnapshot {
  const h = book.mlHome;
  const d = book.mlDraw;
  const a = book.mlAway;
  let impliedHome = h == null ? null : americanToProb(h);
  let impliedDraw = d == null ? null : americanToProb(d);
  let impliedAway = a == null ? null : americanToProb(a);
  if (impliedHome != null && impliedDraw != null && impliedAway != null) {
    const s = impliedHome + impliedDraw + impliedAway;
    impliedHome /= s;
    impliedDraw /= s;
    impliedAway /= s;
  }
  const impliedOver = book.overOdds == null ? null : americanToProb(book.overOdds);
  const impliedUnder = book.underOdds == null ? null : americanToProb(book.underOdds);
  let io = impliedOver;
  let iu = impliedUnder;
  if (io != null && iu != null) {
    const s = io + iu;
    io /= s;
    iu /= s;
  }
  return {
    ...book,
    impliedHome,
    impliedDraw,
    impliedAway,
    impliedOver: io,
    impliedUnder: iu,
  };
}
