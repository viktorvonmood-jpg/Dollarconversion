import { createServerFn } from "@tanstack/react-start";
import type { BoardPayload, MatchDetail } from "./types";

export const loadBoard = createServerFn({ method: "POST" }).handler(
  async (): Promise<BoardPayload> => {
    const { fetchBoard } = await import("./espn.server");
    return fetchBoard();
  },
);

export const loadMatch = createServerFn({ method: "POST" })
  .validator((input: { league: string; eventId: string }) => input)
  .handler(async ({ data }): Promise<MatchDetail | null> => {
    const { fetchMatchDetail } = await import("./espn.server");
    return fetchMatchDetail(data.league, data.eventId);
  });

export const briefMatch = createServerFn({ method: "POST" })
  .validator((input: { title: string; context: string }) => input)
  .handler(async ({ data }): Promise<{ ok: true; text: string } | { ok: false; error: string }> => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false, error: "Analyst notes are unavailable right now." };

    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        max_tokens: 380,
        temperature: 0.4,
        messages: [
          {
            role: "system",
            content:
              "You are the match desk at Crossbar, a football betting-markets product. Write 3 short paragraphs, no emoji, no hype. Cover double chance, Over 1.5 / Over 2.5, corners, cards, shots on target, and hitting the woodwork/crossbar. Be specific to the numbers given. Flag where the model disagrees with the book. Plain language. Not financial advice.",
          },
          {
            role: "user",
            content: `${data.title}\n\n${data.context}`,
          },
        ],
      }),
    });
    if (!res.ok) return { ok: false, error: "The analyst desk is unavailable right now." };
    const body = (await res.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    const text = body.choices?.[0]?.message?.content?.trim() ?? "";
    if (!text) return { ok: false, error: "Empty note from the desk." };
    return { ok: true, text };
  });
