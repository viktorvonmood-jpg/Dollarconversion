const FACT = [1];
for (let i = 1; i <= 16; i += 1) FACT[i] = FACT[i - 1] * i;

export function poissonPmf(k: number, lambda: number): number {
  if (k < 0 || lambda <= 0) return k === 0 && lambda <= 0 ? 1 : 0;
  if (k > 16) return 0;
  return Math.exp(-lambda) * Math.pow(lambda, k) / FACT[k];
}

export function poissonCdf(k: number, lambda: number): number {
  let sum = 0;
  for (let i = 0; i <= k; i += 1) sum += poissonPmf(i, lambda);
  return Math.min(1, sum);
}

/** P(X > line) for a half-line such as 2.5 → P(X >= 3). */
export function poissonOver(line: number, lambda: number): number {
  const threshold = Math.floor(line);
  return 1 - poissonCdf(threshold, lambda);
}

export function clamp(n: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, n));
}

export function round1(n: number): number {
  return Math.round(n * 10) / 10;
}

export function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

export function americanToProb(odds: number): number {
  if (odds < 0) return -odds / (-odds + 100);
  return 100 / (odds + 100);
}

export function parseAmerican(value: unknown): number | null {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string") {
    const n = Number(value.replace("+", "").trim());
    return Number.isFinite(n) ? n : null;
  }
  return null;
}

export function devig3(
  a: number | null,
  b: number | null,
  c: number | null,
): [number, number, number] | null {
  if (a == null || b == null || c == null) return null;
  const pa = americanToProb(a);
  const pb = americanToProb(b);
  const pc = americanToProb(c);
  const s = pa + pb + pc;
  if (s <= 0) return null;
  return [pa / s, pb / s, pc / s];
}

export function fairDecimal(p: number): number {
  if (p <= 0.02) return 50;
  if (p >= 0.98) return 1.02;
  return round2(1 / p);
}

export function confidenceFrom(p: number, sample: number, edge: number | null): number {
  const distance = Math.abs(p - 0.5) * 2;
  const sampleQ = clamp(sample / 10, 0.2, 1);
  const edgeQ = edge == null ? distance : clamp(Math.abs(edge) / 0.1, 0, 1);
  return Math.round(clamp(32 + 38 * distance + 18 * sampleQ + 12 * edgeQ, 38, 96));
}

export function nearestLine(expected: number, lines: number[]): number {
  let best = lines[0]!;
  let bestDist = Math.abs(expected - best);
  for (const line of lines) {
    const dist = Math.abs(expected - line);
    if (dist < bestDist) {
      best = line;
      bestDist = dist;
    }
  }
  return best;
}

export function leanScore(
  key: "double_chance" | "over_15" | string,
  probability: number,
  confidence: number,
  edge: number | null,
): number {
  const baseline = key === "double_chance" ? 0.78 : key === "over_15" ? 0.74 : 0.5;
  return (probability - baseline) * 140 + (edge ?? 0) * 80 + (confidence - 50);
}

export function formatPct(p: number): string {
  return `${Math.round(p * 100)}%`;
}

export function formatKickoff(iso: string): { day: string; time: string; group: string } {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) {
    return { day: "TBD", time: "", group: "Upcoming" };
  }
  const now = new Date();
  const startToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const startKick = new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime();
  const dayDiff = Math.round((startKick - startToday) / 86_400_000);
  let group = date.toLocaleDateString(undefined, {
    weekday: "long",
    month: "short",
    day: "numeric",
  });
  if (dayDiff === 0) group = "Today";
  else if (dayDiff === 1) group = "Tomorrow";
  else if (dayDiff === -1) group = "Yesterday";

  return {
    day: date.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" }),
    time: date.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" }),
    group,
  };
}
