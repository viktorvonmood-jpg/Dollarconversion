import { Link } from "@tanstack/react-router";
import { MapPin } from "lucide-react";
import { formatKickoff, formatPct } from "@/lib/football/math";
import type { PredictedMatch } from "@/lib/football/types";
import { FormRow } from "./form-row";
import { MarketChip } from "./market-chip";
import { TeamCrest } from "./team-crest";
import { Badge } from "./ui/badge";

export function MatchCard({ match, delay = 0 }: { match: PredictedMatch; delay?: number }) {
  const when = formatKickoff(match.kickoff);
  return (
    <article
      className="stagger-in rounded-xl border border-border bg-card p-4 shadow-[var(--shadow-card)] sm:p-5"
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className="mb-4 flex items-center justify-between gap-3 text-[11px] tracking-wide text-muted-foreground uppercase">
        <span className="flex items-center gap-2">
          <span className="text-foreground/80">{match.leagueShort}</span>
          <span aria-hidden>·</span>
          <span>
            {when.day} {when.time}
          </span>
        </span>
        {match.status === "in" ? <Badge variant="live">Live</Badge> : null}
      </div>

      <Link
        to="/match/$league/$eventId"
        params={{ league: match.league, eventId: match.id }}
        className="grid grid-cols-[1fr_auto_1fr] items-center gap-3 rounded-lg outline-none focus-visible:ring-2 focus-visible:ring-ring/70"
      >
        <TeamBlock team={match.home} align="left" liveScore={match.status === "in" ? match.home.score : null} />
        <span className="text-[11px] tracking-[0.2em] text-muted-foreground uppercase">v</span>
        <TeamBlock team={match.away} align="right" liveScore={match.status === "in" ? match.away.score : null} />
      </Link>

      {match.venue ? (
        <p className="mt-3 flex items-center gap-1.5 text-xs text-muted-foreground">
          <MapPin className="size-3" />
          {match.venue}
          {match.city ? ` · ${match.city}` : ""}
        </p>
      ) : null}

      <div className="mt-4 rounded-md border border-border bg-background/50 px-3 py-2">
        <p className="text-[10px] tracking-wide text-muted-foreground uppercase">Top lean</p>
        <p className="flex items-baseline justify-between gap-3 text-sm">
          <span className="font-medium">{match.topPick.pick}</span>
          <span className="tabular-nums text-lean">{formatPct(match.topPick.probability)}</span>
        </p>
      </div>

      <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
        {match.markets.map((pick) => (
          <MarketChip key={pick.key} match={match} pick={pick} />
        ))}
      </div>
    </article>
  );
}

function TeamBlock({
  team,
  align,
  liveScore,
}: {
  team: PredictedMatch["home"];
  align: "left" | "right";
  liveScore: number | null;
}) {
  return (
    <div className={align === "right" ? "flex flex-row-reverse items-center gap-2" : "flex items-center gap-2"}>
      <TeamCrest src={team.logo} name={team.abbr} color={team.color} />
      <div className={align === "right" ? "min-w-0 text-right" : "min-w-0"}>
        <p className="truncate font-medium">{team.shortName}</p>
        <div
          className={
            align === "right"
              ? "mt-0.5 flex flex-row-reverse items-center gap-2"
              : "mt-0.5 flex items-center gap-2"
          }
        >
          {liveScore != null ? (
            <span className="tabular-nums text-lg leading-none">{liveScore}</span>
          ) : (
            <span className="text-[11px] text-muted-foreground tabular-nums">{team.record}</span>
          )}
          <FormRow form={team.form} />
        </div>
      </div>
    </div>
  );
}
