import { Link } from "@tanstack/react-router";
import { Layers } from "lucide-react";
import { useEffect, useState } from "react";
import { useSlip } from "@/lib/slip/store";
import { Button } from "./ui/button";

export function AppHeader() {
  const count = useSlip((s) => s.legs.length);
  const setOpen = useSlip((s) => s.setOpen);
  const [ready, setReady] = useState(false);
  useEffect(() => setReady(true), []);
  const shown = ready ? count : 0;

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/85 backdrop-blur-sm">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4 sm:px-6">
        <Link to="/" className="flex items-center gap-3 outline-none focus-visible:ring-2 focus-visible:ring-ring/70">
          <span className="relative flex size-8 items-center justify-center rounded-md border border-border">
            <span className="absolute top-1.5 h-px w-4 bg-foreground" />
            <span className="mt-2 size-1.5 rounded-full bg-foreground" />
          </span>
          <span className="flex flex-col leading-none">
            <span className="font-display text-xl tracking-tight">Crossbar</span>
            <span className="text-xs tracking-[0.18em] text-muted-foreground uppercase">
              Markets desk
            </span>
          </span>
        </Link>
        <Button variant="outline" size="sm" onClick={() => setOpen(true)} className="min-w-11">
          <Layers />
          Slip
          {shown > 0 ? (
            <span className="rounded-full bg-primary px-1.5 text-xs text-primary-foreground tabular-nums">
              {shown}
            </span>
          ) : null}
        </Button>
      </div>
    </header>
  );
}
