import { Trash2 } from "lucide-react";
import { formatKickoff, formatPct } from "@/lib/football/math";
import { combinedOdds, combinedProbability, useSlip } from "@/lib/slip/store";
import { Button } from "./ui/button";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "./ui/sheet";

export function SlipSheet() {
  const open = useSlip((s) => s.open);
  const setOpen = useSlip((s) => s.setOpen);
  const legs = useSlip((s) => s.legs);
  const remove = useSlip((s) => s.remove);
  const clear = useSlip((s) => s.clear);
  const combined = combinedProbability(legs);
  const odds = combinedOdds(legs);

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetContent side="right" className="w-full sm:max-w-md">
        <SheetHeader>
          <SheetTitle>Accumulator</SheetTitle>
          <SheetDescription>
            Up to eight legs. Combined probability is the product of model prices — not a book quote.
          </SheetDescription>
        </SheetHeader>

        <div className="min-h-0 flex-1 overflow-y-auto">
          {legs.length === 0 ? (
            <p className="py-10 text-sm text-muted-foreground">
              No legs yet. Add a double chance, totals, corners, cards, shots or woodwork pick from the board.
            </p>
          ) : (
            <ul className="flex flex-col gap-2">
              {legs.map((leg) => {
                const when = formatKickoff(leg.kickoff);
                return (
                  <li
                    key={leg.id}
                    className="flex items-start gap-3 rounded-lg border border-border bg-background/70 p-3"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="text-[11px] tracking-wide text-muted-foreground uppercase">
                        {leg.homeAbbr} v {leg.awayAbbr} · {when.day}
                      </p>
                      <p className="text-sm font-medium">{leg.pick}</p>
                      <p className="text-xs text-muted-foreground">{leg.title}</p>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <span className="tabular-nums text-sm text-lean">{formatPct(leg.probability)}</span>
                      <button
                        type="button"
                        onClick={() => remove(leg.id)}
                        className="text-muted-foreground hover:text-foreground"
                        aria-label="Remove leg"
                      >
                        <Trash2 className="size-4" />
                      </button>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </div>

        <div className="mt-auto flex flex-col gap-3 border-t border-border pt-4">
          <div className="flex items-end justify-between">
            <div>
              <p className="text-[11px] tracking-wide text-muted-foreground uppercase">Combined model</p>
              <p className="font-display text-3xl leading-none tabular-nums">
                {legs.length ? formatPct(combined) : "—"}
              </p>
            </div>
            <p className="text-sm text-muted-foreground">
              Fair acca {legs.length ? `${odds.toFixed(2)}` : "—"}
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" className="flex-1" onClick={clear} disabled={!legs.length}>
              Clear
            </Button>
            <Button className="flex-1" onClick={() => setOpen(false)}>
              Keep building
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
