import { cn } from "@/lib/utils";

export function FormRow({ form }: { form: string }) {
  const chars = form.replace(/[^WDL]/gi, "").slice(0, 5).split("");
  if (!chars.length) return null;
  return (
    <span className="inline-flex items-center gap-0.5" aria-label={`Form ${chars.join(" ")}`}>
      {chars.map((char, i) => {
        const c = char.toUpperCase();
        return (
          <span
            key={`${c}-${i}`}
            className={cn(
              "inline-flex size-4 items-center justify-center rounded-xs text-[9px] font-semibold",
              c === "W" && "bg-lean/20 text-lean",
              c === "D" && "bg-secondary text-muted-foreground",
              c === "L" && "bg-live/15 text-live",
            )}
          >
            {c}
          </span>
        );
      })}
    </span>
  );
}
