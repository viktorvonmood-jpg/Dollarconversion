import { formatPct } from "@/lib/football/math";
import { cn } from "@/lib/utils";

export function OutcomeBar({
  home,
  draw,
  away,
  homeLabel,
  awayLabel,
}: {
  home: number;
  draw: number;
  away: number;
  homeLabel: string;
  awayLabel: string;
}) {
  const h = Math.max(home * 100, 4);
  const d = Math.max(draw * 100, 4);
  const a = Math.max(away * 100, 4);
  return (
    <div className="flex flex-col gap-2">
      <div className="flex h-2 overflow-hidden rounded-full bg-muted">
        <span className="bg-foreground/85" style={{ width: `${h}%` }} />
        <span className="bg-muted-foreground/50" style={{ width: `${d}%` }} />
        <span className="bg-foreground/35" style={{ width: `${a}%` }} />
      </div>
      <div className="grid grid-cols-3 text-[11px] tracking-wide text-muted-foreground uppercase">
        <span>
          {homeLabel} <span className="tabular-nums text-foreground">{formatPct(home)}</span>
        </span>
        <span className="text-center">
          Draw <span className="tabular-nums text-foreground">{formatPct(draw)}</span>
        </span>
        <span className="text-right">
          {awayLabel} <span className="tabular-nums text-foreground">{formatPct(away)}</span>
        </span>
      </div>
    </div>
  );
}

export function Meter({ value, className }: { value: number; className?: string }) {
  return (
    <div className={cn("h-1.5 overflow-hidden rounded-full bg-muted", className)}>
      <div
        className="h-full rounded-full bg-lean"
        style={{ width: `${Math.round(value * 100)}%` }}
      />
    </div>
  );
}
