import { Plus, Check } from "lucide-react";
import { formatPct } from "@/lib/football/math";
import type { MarketPick, PredictedMatch } from "@/lib/football/types";
import { useSlip } from "@/lib/slip/store";
import { cn } from "@/lib/utils";

export function MarketChip({
  match,
  pick,
  compact = false,
}: {
  match: PredictedMatch;
  pick: MarketPick;
  compact?: boolean;
}) {
  const add = useSlip((s) => s.add);
  const legs = useSlip((s) => s.legs);
  const onSlip = legs.some((leg) => leg.matchId === match.id && leg.marketKey === pick.key);

  return (
    <div
      className={cn(
        "flex items-center gap-2 rounded-md border border-border bg-background/60 px-2.5 py-2",
        compact && "flex-col items-stretch gap-1 px-2 py-1.5",
      )}
    >
      <div className="min-w-0 flex-1">
        <p className="truncate text-[10px] tracking-wide text-muted-foreground uppercase">
          {pick.title}
        </p>
        <p className="truncate text-sm font-medium text-foreground">{pick.pick}</p>
      </div>
      <div className="flex items-center gap-2">
        <span className="tabular-nums text-sm text-lean">{formatPct(pick.probability)}</span>
        <button
          type="button"
          aria-label={onSlip ? "On slip" : `Add ${pick.pick}`}
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            add(match, pick);
          }}
          className={cn(
            "inline-flex size-8 items-center justify-center rounded-sm border border-border text-muted-foreground transition-colors hover:text-foreground",
            onSlip && "border-lean/40 bg-lean/10 text-lean",
          )}
        >
          {onSlip ? <Check className="size-3.5" /> : <Plus className="size-3.5" />}
        </button>
      </div>
    </div>
  );
}
