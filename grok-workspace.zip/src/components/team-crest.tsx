import { useState } from "react";
import { cn } from "@/lib/utils";

export function TeamCrest({
  src,
  name,
  color,
  size = "md",
}: {
  src: string;
  name: string;
  color: string;
  size?: "sm" | "md" | "lg";
}) {
  const [failed, setFailed] = useState(false);
  const dim = size === "lg" ? "size-14" : size === "sm" ? "size-8" : "size-11";
  if (failed) {
    return (
      <div
        className={cn(
          "flex shrink-0 items-center justify-center rounded-full text-[10px] font-semibold tracking-wide text-foreground",
          dim,
        )}
        style={{ backgroundColor: `#${color || "3f4550"}` }}
        aria-hidden
      >
        {name.slice(0, 2).toUpperCase()}
      </div>
    );
  }
  return (
    <img
      src={src}
      alt=""
      width={56}
      height={56}
      loading="lazy"
      onError={() => setFailed(true)}
      className={cn("shrink-0 object-contain", dim)}
    />
  );
}
