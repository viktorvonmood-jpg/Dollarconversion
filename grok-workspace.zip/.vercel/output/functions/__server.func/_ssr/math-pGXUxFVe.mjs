//#region node_modules/.nitro/vite/services/ssr/assets/math-pGXUxFVe.js
var FACT = [1];
for (let i = 1; i <= 16; i += 1) FACT[i] = FACT[i - 1] * i;
function poissonPmf(k, lambda) {
	if (k < 0 || lambda <= 0) return k === 0 && lambda <= 0 ? 1 : 0;
	if (k > 16) return 0;
	return Math.exp(-lambda) * Math.pow(lambda, k) / FACT[k];
}
function poissonCdf(k, lambda) {
	let sum = 0;
	for (let i = 0; i <= k; i += 1) sum += poissonPmf(i, lambda);
	return Math.min(1, sum);
}
/** P(X > line) for a half-line such as 2.5 → P(X >= 3). */
function poissonOver(line, lambda) {
	return 1 - poissonCdf(Math.floor(line), lambda);
}
function clamp(n, min, max) {
	return Math.min(max, Math.max(min, n));
}
function round1(n) {
	return Math.round(n * 10) / 10;
}
function round2(n) {
	return Math.round(n * 100) / 100;
}
function americanToProb(odds) {
	if (odds < 0) return -odds / (-odds + 100);
	return 100 / (odds + 100);
}
function parseAmerican(value) {
	if (typeof value === "number" && Number.isFinite(value)) return value;
	if (typeof value === "string") {
		const n = Number(value.replace("+", "").trim());
		return Number.isFinite(n) ? n : null;
	}
	return null;
}
function fairDecimal(p) {
	if (p <= .02) return 50;
	if (p >= .98) return 1.02;
	return round2(1 / p);
}
function confidenceFrom(p, sample, edge) {
	const distance = Math.abs(p - .5) * 2;
	const sampleQ = clamp(sample / 10, .2, 1);
	const edgeQ = edge == null ? distance : clamp(Math.abs(edge) / .1, 0, 1);
	return Math.round(clamp(32 + 38 * distance + 18 * sampleQ + 12 * edgeQ, 38, 96));
}
function nearestLine(expected, lines) {
	let best = lines[0];
	let bestDist = Math.abs(expected - best);
	for (const line of lines) {
		const dist = Math.abs(expected - line);
		if (dist < bestDist) {
			best = line;
			bestDist = dist;
		}
	}
	return best;
}
function leanScore(key, probability, confidence, edge) {
	return (probability - (key === "double_chance" ? .78 : key === "over_15" ? .74 : .5)) * 140 + (edge ?? 0) * 80 + (confidence - 50);
}
function formatPct(p) {
	return `${Math.round(p * 100)}%`;
}
function formatKickoff(iso) {
	const date = new Date(iso);
	if (Number.isNaN(date.getTime())) return {
		day: "TBD",
		time: "",
		group: "Upcoming"
	};
	const now = /* @__PURE__ */ new Date();
	const startToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
	const startKick = new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime();
	const dayDiff = Math.round((startKick - startToday) / 864e5);
	let group = date.toLocaleDateString(void 0, {
		weekday: "long",
		month: "short",
		day: "numeric"
	});
	if (dayDiff === 0) group = "Today";
	else if (dayDiff === 1) group = "Tomorrow";
	else if (dayDiff === -1) group = "Yesterday";
	return {
		day: date.toLocaleDateString(void 0, {
			weekday: "short",
			month: "short",
			day: "numeric"
		}),
		time: date.toLocaleTimeString(void 0, {
			hour: "2-digit",
			minute: "2-digit"
		}),
		group
	};
}
//#endregion
export { formatKickoff as a, nearestLine as c, poissonPmf as d, round1 as f, fairDecimal as i, parseAmerican as l, clamp as n, formatPct as o, round2 as p, confidenceFrom as r, leanScore as s, americanToProb as t, poissonOver as u };
