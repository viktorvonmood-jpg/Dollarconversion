import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/functions-B0asLnTE.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var loadBoard_createServerFn_handler = createServerRpc({
	id: "88b49dbf07ad1a40a3c37974e3313023e153ef9c40065613e95d55e3f1e6d493",
	name: "loadBoard",
	filename: "src/lib/football/functions.ts"
}, (opts) => loadBoard.__executeServer(opts));
var loadBoard = createServerFn({ method: "POST" }).handler(loadBoard_createServerFn_handler, async () => {
	const { fetchBoard } = await import("./espn.server-B_dqzvdX.mjs");
	return fetchBoard();
});
var loadMatch_createServerFn_handler = createServerRpc({
	id: "1237394747655ae56cc41085e60ee1eae84d0fe7a47b92e83203e1ba51fcc393",
	name: "loadMatch",
	filename: "src/lib/football/functions.ts"
}, (opts) => loadMatch.__executeServer(opts));
var loadMatch = createServerFn({ method: "POST" }).validator((input) => input).handler(loadMatch_createServerFn_handler, async ({ data }) => {
	const { fetchMatchDetail } = await import("./espn.server-B_dqzvdX.mjs");
	return fetchMatchDetail(data.league, data.eventId);
});
var briefMatch_createServerFn_handler = createServerRpc({
	id: "72542244dee4bc3a1cf9faba907d7aa32347f54f3138863651f815fdc275a448",
	name: "briefMatch",
	filename: "src/lib/football/functions.ts"
}, (opts) => briefMatch.__executeServer(opts));
var briefMatch = createServerFn({ method: "POST" }).validator((input) => input).handler(briefMatch_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "Analyst notes are unavailable right now."
	};
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: "grok-4.5",
			max_tokens: 380,
			temperature: .4,
			messages: [{
				role: "system",
				content: "You are the match desk at Crossbar, a football betting-markets product. Write 3 short paragraphs, no emoji, no hype. Cover double chance, Over 1.5 / Over 2.5, corners, cards, shots on target, and hitting the woodwork/crossbar. Be specific to the numbers given. Flag where the model disagrees with the book. Plain language. Not financial advice."
			}, {
				role: "user",
				content: `${data.title}\n\n${data.context}`
			}]
		})
	});
	if (!res.ok) return {
		ok: false,
		error: "The analyst desk is unavailable right now."
	};
	const text = (await res.json()).choices?.[0]?.message?.content?.trim() ?? "";
	if (!text) return {
		ok: false,
		error: "Empty note from the desk."
	};
	return {
		ok: true,
		text
	};
});
//#endregion
export { briefMatch_createServerFn_handler, loadBoard_createServerFn_handler, loadMatch_createServerFn_handler };
