import { a as formatKickoff, o as formatPct } from "./math-pGXUxFVe.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as PenLine, l as ArrowLeft } from "../_libs/lucide-react.mjs";
import { n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
import { i as cn, n as Route, r as Button } from "./router-ftrmobCt.mjs";
import { a as Skeleton, i as MarketChip, l as loadMatch, n as Badge, o as TeamCrest, r as FormRow, s as briefMatch, t as AppHeader } from "./functions-CC0dpPUj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/match._league._eventId-fU9rM2cU.js
var import_jsx_runtime = require_jsx_runtime();
function OutcomeBar({ home, draw, away, homeLabel, awayLabel }) {
	const h = Math.max(home * 100, 4);
	const d = Math.max(draw * 100, 4);
	const a = Math.max(away * 100, 4);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex h-2 overflow-hidden rounded-full bg-muted",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "bg-foreground/85",
					style: { width: `${h}%` }
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "bg-muted-foreground/50",
					style: { width: `${d}%` }
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "bg-foreground/35",
					style: { width: `${a}%` }
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-3 text-[11px] tracking-wide text-muted-foreground uppercase",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					homeLabel,
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums text-foreground",
						children: formatPct(home)
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-center",
					children: ["Draw ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums text-foreground",
						children: formatPct(draw)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-right",
					children: [
						awayLabel,
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums text-foreground",
							children: formatPct(away)
						})
					]
				})
			]
		})]
	});
}
function Separator({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: cn("h-px w-full bg-border", className) });
}
function MatchPage() {
	const { league, eventId } = Route.useParams();
	const q = useQuery({
		queryKey: [
			"match",
			league,
			eventId
		],
		queryFn: () => loadMatch({ data: {
			league,
			eventId
		} })
	});
	if (q.isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppHeader, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-3xl px-4 py-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-40" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "mt-8 h-32 w-full" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "mt-6 h-48 w-full" })
			]
		})]
	});
	if (!q.data) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppHeader, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-3xl px-4 py-16 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-3xl",
					children: "Match not on the board"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "It may have finished, or the feed moved on."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						children: "Back to desk"
					})
				})
			]
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchDesk, { match: q.data });
}
function MatchDesk({ match }) {
	const when = formatKickoff(match.kickoff);
	const brief = useMutation({ mutationFn: () => briefMatch({ data: {
		title: `${match.home.name} vs ${match.away.name} · ${match.leagueName} · ${when.day} ${when.time}`,
		context: [
			`Venue: ${match.venue ?? "n/a"} (${match.city ?? ""})`,
			`Form ${match.home.abbr} ${match.home.form} (${match.home.record}${match.home.rank ? `, #${match.home.rank}` : ""})`,
			`Form ${match.away.abbr} ${match.away.form} (${match.away.record}${match.away.rank ? `, #${match.away.rank}` : ""})`,
			`Model 1X2 ${formatPct(match.probs.home)} / ${formatPct(match.probs.draw)} / ${formatPct(match.probs.away)}`,
			`xG ${match.expected.homeGoals}-${match.expected.awayGoals} (total ${match.expected.totalGoals})`,
			`O1.5 ${formatPct(match.probs.over15)} · O2.5 ${formatPct(match.probs.over25)} · O3.5 ${formatPct(match.probs.over35)}`,
			`Corners ${match.expected.corners} · Cards ${match.expected.cards} · SOT ${match.expected.sot} · Woodwork ${match.expected.woodwork}`,
			match.book ? `Book ML ${match.book.mlHome ?? "n/a"} / ${match.book.mlDraw ?? "n/a"} / ${match.book.mlAway ?? "n/a"} · O/U ${match.book.overUnder ?? "n/a"}` : "No book line on the feed.",
			...match.markets.map((m) => `${m.title}: ${m.pick} ${formatPct(m.probability)} conf ${m.confidence}`)
		].join("\n")
	} }) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppHeader, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto max-w-3xl px-4 pt-6 pb-24 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "inline-flex h-11 items-center gap-2 text-sm text-muted-foreground hover:text-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), "Desk"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-6 text-xs tracking-[0.2em] text-muted-foreground uppercase",
					children: [
						match.leagueName,
						" · ",
						when.day,
						" ",
						when.time,
						match.status === "in" ? " · Live" : ""
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid grid-cols-[1fr_auto_1fr] items-center gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamHero, {
							team: match.home,
							align: "left",
							score: match.status === "in" ? match.home.score : null
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-center",
							children: match.status === "in" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								variant: "live",
								children: "Live"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-2xl text-muted-foreground",
								children: "v"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamHero, {
							team: match.away,
							align: "right",
							score: match.status === "in" ? match.away.score : null
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 text-center text-xs text-muted-foreground",
					children: [match.venue ?? "Venue TBC", match.city ? ` · ${match.city}` : ""]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-8 rounded-xl border border-border bg-card p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl tracking-tight",
							children: "1X2 shape"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: [
								"Expected goals ",
								match.expected.homeGoals,
								"–",
								match.expected.awayGoals,
								" · total ",
								match.expected.totalGoals
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OutcomeBar, {
								home: match.probs.home,
								draw: match.probs.draw,
								away: match.probs.away,
								homeLabel: match.home.abbr,
								awayLabel: match.away.abbr
							})
						}),
						match.book?.impliedHome != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-xs text-muted-foreground",
							children: [
								"Book (devig) ",
								formatPct(match.book.impliedHome),
								" / ",
								formatPct(match.book.impliedDraw ?? 0),
								" /",
								" ",
								formatPct(match.book.impliedAway ?? 0),
								match.book.overUnder != null ? ` · listed total ${match.book.overUnder}` : ""
							]
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-6 grid grid-cols-2 gap-2 sm:grid-cols-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "xG total",
							value: String(match.expected.totalGoals)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Corners",
							value: String(match.expected.corners)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Cards",
							value: String(match.expected.cards)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "SOT / bar",
							value: `${match.expected.sot} / ${match.expected.woodwork}`
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl tracking-tight",
							children: "Market sheet"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 mb-4 text-sm text-muted-foreground",
							children: "Add a pick to the slip. Fair odds are 1 / model probability."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-col gap-2",
							children: match.markets.map((pick) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-lg border border-border bg-card p-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketChip, {
										match,
										pick
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-xs leading-relaxed text-muted-foreground",
										children: pick.rationale
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 text-xs text-muted-foreground tabular-nums",
										children: [
											"Fair ",
											pick.fairOdds.toFixed(2),
											pick.edge != null ? ` · edge ${pick.edge > 0 ? "+" : ""}${Math.round(pick.edge * 100)} pts` : "",
											` · confidence ${pick.confidence}`
										]
									})
								]
							}, pick.key))
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-8 grid gap-4 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecentCard, {
						name: match.home.shortName,
						recents: match.recents.home
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecentCard, {
						name: match.away.shortName,
						recents: match.recents.away
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-8 rounded-xl border border-border bg-card p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-2xl tracking-tight",
								children: "Desk note"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: "Optional analyst write-up from the same sheet. One request per read."
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								disabled: brief.isPending,
								onClick: () => brief.mutate(),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, {}), brief.isPending ? "Writing" : "Ask the desk"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, { className: "my-4" }),
						brief.data?.ok === true ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-3 text-sm leading-relaxed text-foreground/90",
							children: brief.data.text.split(/\n\n+/).map((para, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: para }, i))
						}) : brief.data && !brief.data.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: brief.data.error
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "The note uses this match’s numbers only. It is not a bet recommendation."
						})
					]
				})
			]
		})]
	});
}
function TeamHero({ team, align, score }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex min-w-0 items-center gap-3", align === "right" && "flex-row-reverse"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamCrest, {
			src: team.logo,
			name: team.abbr,
			color: team.color,
			size: "lg"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("min-w-0", align === "right" && "text-right"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate font-display text-2xl leading-tight tracking-tight sm:text-3xl",
					children: team.shortName
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("mt-1 flex items-center gap-2", align === "right" && "flex-row-reverse"),
					children: [score != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-3xl tabular-nums",
						children: score
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground tabular-nums",
						children: team.record
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormRow, { form: team.form })]
				}),
				team.rank ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-xs tracking-wide text-muted-foreground uppercase",
					children: [team.rank === 1 ? "1st" : team.rank === 2 ? "2nd" : team.rank === 3 ? "3rd" : `${team.rank}th`, team.pts ? ` · ${team.pts} pts` : ""]
				}) : null
			]
		})]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-border bg-card px-3 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs tracking-wide text-muted-foreground uppercase",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-2xl tabular-nums",
			children: value
		})]
	});
}
function RecentCard({ name, recents }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-border bg-card p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
			className: "text-sm font-medium",
			children: [name, " · last five"]
		}), recents.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-3 text-xs text-muted-foreground",
			children: "No recent sheet on the feed."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-3 flex flex-col gap-2",
			children: recents.map((row, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center justify-between gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "min-w-0 truncate text-muted-foreground",
					children: [
						row.atHome ? "vs" : "@",
						" ",
						row.opponentAbbr
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: row.score
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("inline-flex size-5 items-center justify-center rounded-xs text-xs font-semibold", row.result === "W" && "bg-lean/20 text-lean", row.result === "D" && "bg-secondary text-muted-foreground", row.result === "L" && "bg-live/15 text-live"),
						children: row.result
					})]
				})]
			}, `${row.date}-${i}`))
		})]
	});
}
//#endregion
export { MatchPage as component };
