import { n as LEAGUE_BY_SLUG, t as LEAGUES } from "./leagues-BKToWlwo.mjs";
import { c as nearestLine, d as poissonPmf, f as round1, i as fairDecimal, l as parseAmerican, n as clamp, p as round2, r as confidenceFrom, s as leanScore, t as americanToProb, u as poissonOver } from "./math-pGXUxFVe.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/espn.server-B_dqzvdX.js
function formScore(form) {
	const chars = form.replace(/[^WDLwdl]/g, "").split("");
	if (!chars.length) return .45;
	let weighted = 0;
	let total = 0;
	chars.forEach((char, index) => {
		const recency = Math.pow(.82, index);
		const value = char.toUpperCase() === "W" ? 1 : char.toUpperCase() === "D" ? .42 : 0;
		weighted += value * recency;
		total += recency;
	});
	return total ? weighted / total : .45;
}
function parseRecord(record) {
	const parts = record.split("-").map((p) => Number(p.trim()));
	const w = parts[0] || 0;
	const d = parts[1] || 0;
	const l = parts[2] || 0;
	return {
		w,
		d,
		l,
		gp: w + d + l
	};
}
function outcomeProbs(lh, la) {
	const max = 10;
	let home = 0;
	let draw = 0;
	let away = 0;
	let over15 = 0;
	let over25 = 0;
	let over35 = 0;
	for (let i = 0; i <= max; i += 1) {
		const pi = poissonPmf(i, lh);
		for (let j = 0; j <= max; j += 1) {
			const p = pi * poissonPmf(j, la);
			if (i > j) home += p;
			else if (i === j) draw += p;
			else away += p;
			const total = i + j;
			if (total >= 2) over15 += p;
			if (total >= 3) over25 += p;
			if (total >= 4) over35 += p;
		}
	}
	const s = home + draw + away;
	return {
		home: home / s,
		draw: draw / s,
		away: away / s,
		over15,
		over25,
		over35
	};
}
function strengthFor(team, table, leagueAvg) {
	const rated = table?.byId[team.id];
	if (rated && rated.gp >= 2) return {
		attack: clamp(rated.attack, .45, 1.85),
		defense: clamp(rated.defense, .45, 1.85),
		sample: rated.gp
	};
	const rec = parseRecord(team.record);
	const gp = rec.gp || team.gp || 4;
	const gf = team.gf || rec.w * 1.7 + rec.d * 1.05 + rec.l * .55;
	const ga = team.ga || rec.l * 1.65 + rec.d * 1.05 + rec.w * .55;
	return {
		attack: clamp(gf / Math.max(gp, 1) / Math.max(leagueAvg / 2, .8), .5, 1.8),
		defense: clamp(ga / Math.max(gp, 1) / Math.max(leagueAvg / 2, .8), .5, 1.8),
		sample: gp
	};
}
function pickCountMarket(key, title, expected, lines, sample, rationaleBase, bookImpliedOver, bookLine) {
	const line = nearestLine(expected, lines);
	const overP = clamp(poissonOver(line, expected), .08, .94);
	const useOver = overP >= .5;
	const probability = useOver ? overP : 1 - overP;
	const implied = bookLine != null && Math.abs(bookLine - line) < .2 ? bookImpliedOver : null;
	const bookForSide = implied == null ? null : useOver ? implied : 1 - implied;
	const edge = bookForSide == null ? null : round2(probability - bookForSide);
	return {
		key,
		title,
		pick: `${useOver ? "Over" : "Under"} ${line}`,
		line,
		probability,
		fairOdds: fairDecimal(probability),
		bookImplied: bookForSide,
		edge,
		confidence: confidenceFrom(probability, sample, edge),
		rationale: `${rationaleBase} Model expects ${round1(expected)}. ${useOver ? "Over" : "Under"} ${line} at ${Math.round(probability * 100)}%.`
	};
}
function doubleChance(probs, home, away, sample, book) {
	const oneX = probs.home + probs.draw;
	const xTwo = probs.away + probs.draw;
	const twelve = probs.home + probs.away;
	const options = [
		{
			pick: `1X ${home.abbr}`,
			p: oneX,
			why: `${home.shortName} not to lose`
		},
		{
			pick: `X2 ${away.abbr}`,
			p: xTwo,
			why: `${away.shortName} not to lose`
		},
		{
			pick: "1X2 no draw (12)",
			p: twelve,
			why: "Match to have a winner"
		}
	];
	const ranked = [...options].sort((a, b) => b.p - a.p);
	const favoriteSide = probs.home >= probs.away ? options[0] : options[1];
	const chosen = probs.draw < .22 && twelve > .82 && Math.abs(probs.home - probs.away) < .12 ? options[2] : favoriteSide.p >= .62 ? favoriteSide : ranked[0];
	let bookImplied = null;
	if (book?.impliedHome != null && book.impliedDraw != null && book.impliedAway != null) {
		if (chosen.pick.startsWith("1X ")) bookImplied = book.impliedHome + book.impliedDraw;
		else if (chosen.pick.startsWith("X2 ")) bookImplied = book.impliedAway + book.impliedDraw;
		else bookImplied = book.impliedHome + book.impliedAway;
	}
	const edge = bookImplied == null ? null : round2(chosen.p - bookImplied);
	return {
		key: "double_chance",
		title: "Double chance",
		pick: chosen.pick,
		line: null,
		probability: chosen.p,
		fairOdds: fairDecimal(chosen.p),
		bookImplied,
		edge,
		confidence: confidenceFrom(chosen.p, sample, edge),
		rationale: `${chosen.why}. 1X ${Math.round(oneX * 100)}% · 12 ${Math.round(twelve * 100)}% · X2 ${Math.round(xTwo * 100)}%.`
	};
}
function predictMatch(input, table) {
	const profile = LEAGUE_BY_SLUG[input.league] ?? LEAGUE_BY_SLUG["eng.1"];
	const leagueAvg = table?.avgGoals || profile.avgGoals;
	const homeS = strengthFor(input.home, table, leagueAvg);
	const awayS = strengthFor(input.away, table, leagueAvg);
	const homeForm = formScore(input.home.form);
	const awayForm = formScore(input.away.form);
	const homeAttack = homeS.attack * .74 + (.72 + .55 * homeForm) * .26;
	const awayAttack = awayS.attack * .74 + (.72 + .55 * awayForm) * .26;
	const homeDef = homeS.defense * .76 + (1.28 - .5 * homeForm) * .24;
	const awayDef = awayS.defense * .76 + (1.28 - .5 * awayForm) * .24;
	const avgHome = leagueAvg * profile.homeShare;
	const avgAway = leagueAvg * (1 - profile.homeShare);
	let homeGoals = clamp(homeAttack * awayDef * avgHome * (profile.homeAdv / 1.08), .35, 3.6);
	let awayGoals = clamp(awayAttack * homeDef * avgAway / (profile.homeAdv / 1.08), .2, 3.1);
	const probs = outcomeProbs(homeGoals, awayGoals);
	const totalGoals = homeGoals + awayGoals;
	const sample = Math.min(homeS.sample, awayS.sample);
	const mismatch = Math.abs(homeGoals - awayGoals);
	const closeness = 1 - clamp(mismatch / 1.8, 0, 1);
	const attackMean = (homeAttack + awayAttack) / 2;
	const corners = clamp(profile.avgCorners * (.72 + .28 * attackMean) * (.94 + .12 * mismatch * .25), 7.2, 14.5);
	const cards = clamp(profile.avgCards * (.86 + .28 * closeness) * (input.league.includes("bra") || input.league.includes("tur") ? 1.04 : 1), 2.6, 7.2);
	const sot = clamp(totalGoals / .31, 6.2, 14.8);
	const woodwork = clamp(profile.avgWoodwork * (sot / Math.max(profile.avgSot, 8)), .28, 1.05);
	const expected = {
		homeGoals: round2(homeGoals),
		awayGoals: round2(awayGoals),
		totalGoals: round2(totalGoals),
		corners: round1(corners),
		cards: round1(cards),
		sot: round1(sot),
		woodwork: round2(woodwork)
	};
	const bookOver = input.book?.overUnder != null && Math.abs(input.book.overUnder - 2.5) < .2 ? input.book.impliedOver : null;
	const over15P = clamp(probs.over15, .12, .96);
	const over25P = clamp(probs.over25, .08, .9);
	const over15 = {
		key: "over_15",
		title: "Over 1.5 goals",
		pick: over15P >= .5 ? "Over 1.5" : "Under 1.5",
		line: 1.5,
		probability: over15P >= .5 ? over15P : 1 - over15P,
		fairOdds: fairDecimal(over15P >= .5 ? over15P : 1 - over15P),
		bookImplied: null,
		edge: null,
		confidence: confidenceFrom(over15P >= .5 ? over15P : 1 - over15P, sample, null),
		rationale: `Expected goals ${expected.homeGoals}–${expected.awayGoals} (total ${expected.totalGoals}). P(2+ goals) ${Math.round(over15P * 100)}%.`
	};
	const over25Side = over25P >= .5;
	const over25Prob = over25Side ? over25P : 1 - over25P;
	const over25Edge = bookOver == null ? null : round2((over25Side ? over25P : 1 - over25P) - (over25Side ? bookOver : 1 - bookOver));
	const over25 = {
		key: "over_25",
		title: "Over 2.5 / 2.6",
		pick: over25Side ? "Over 2.5" : "Under 2.5",
		line: 2.5,
		probability: over25Prob,
		fairOdds: fairDecimal(over25Prob),
		bookImplied: bookOver == null ? null : over25Side ? bookOver : 1 - bookOver,
		edge: over25Edge,
		confidence: confidenceFrom(over25Prob, sample, over25Edge),
		rationale: `xG total ${expected.totalGoals}. Goals are whole numbers, so Over 2.5 and Over 2.6 are the same call: three or more. Model has ${Math.round(over25P * 100)}% on 3+ goals.`
	};
	const woodP = clamp(poissonOver(.5, woodwork), .18, .78);
	const woodPickOver = woodP >= .5;
	const woodProb = woodPickOver ? woodP : 1 - woodP;
	const woodworkM = {
		key: "woodwork",
		title: "Hitting the crossbar",
		pick: woodPickOver ? "Over 0.5 woodwork" : "Under 0.5 woodwork",
		line: .5,
		probability: woodProb,
		fairOdds: fairDecimal(woodProb),
		bookImplied: null,
		edge: null,
		confidence: confidenceFrom(woodProb, sample, null) - 6,
		rationale: `Posts + bar. Expected woodwork hits ${expected.woodwork} from ${expected.sot} shots on target. Frame events track shot volume, not finishing.`
	};
	const markets = [
		doubleChance(probs, input.home, input.away, sample, input.book),
		over15,
		over25,
		pickCountMarket("corners", "Total corners", corners, [
			8.5,
			9.5,
			10.5,
			11.5
		], sample, `${input.home.abbr} and ${input.away.abbr} generate ${round1(corners)} combined corners.`, null, null),
		pickCountMarket("cards", "Total cards", cards, [
			3.5,
			4.5,
			5.5
		], sample, `Booking climate for ${profile.short} plus match tightness.`, null, null),
		pickCountMarket("sot", "Shots on target", sot, [
			7.5,
			8.5,
			9.5,
			10.5
		], sample, `On-target volume from a ${expected.totalGoals} xG game.`, null, null),
		woodworkM
	].map((m) => ({
		...m,
		confidence: clamp(m.confidence, 36, 94),
		probability: clamp(m.probability, .08, .96)
	}));
	const topPick = [...markets].sort((a, b) => leanScore(b.key, b.probability, b.confidence, b.edge) - leanScore(a.key, a.probability, a.confidence, a.edge))[0];
	return {
		id: input.id,
		league: input.league,
		leagueName: input.leagueName,
		leagueShort: input.leagueShort,
		kickoff: input.kickoff,
		venue: input.venue,
		city: input.city,
		status: input.status,
		statusDetail: input.statusDetail,
		home: input.home,
		away: input.away,
		expected,
		probs,
		markets,
		topPick,
		book: input.book
	};
}
function impliedFromBook(book) {
	const h = book.mlHome;
	const d = book.mlDraw;
	const a = book.mlAway;
	let impliedHome = h == null ? null : americanToProb(h);
	let impliedDraw = d == null ? null : americanToProb(d);
	let impliedAway = a == null ? null : americanToProb(a);
	if (impliedHome != null && impliedDraw != null && impliedAway != null) {
		const s = impliedHome + impliedDraw + impliedAway;
		impliedHome /= s;
		impliedDraw /= s;
		impliedAway /= s;
	}
	const impliedOver = book.overOdds == null ? null : americanToProb(book.overOdds);
	const impliedUnder = book.underOdds == null ? null : americanToProb(book.underOdds);
	let io = impliedOver;
	let iu = impliedUnder;
	if (io != null && iu != null) {
		const s = io + iu;
		io /= s;
		iu /= s;
	}
	return {
		...book,
		impliedHome,
		impliedDraw,
		impliedAway,
		impliedOver: io,
		impliedUnder: iu
	};
}
var UA = "Mozilla/5.0 (compatible; CrossbarPredictions/1.0)";
var TTL_MS = 42e4;
var cache = /* @__PURE__ */ new Map();
function readCache(key) {
	const hit = cache.get(key);
	if (!hit) return null;
	if (Date.now() - hit.at > TTL_MS) {
		cache.delete(key);
		return null;
	}
	return hit.data;
}
function writeCache(key, data) {
	cache.set(key, {
		at: Date.now(),
		data
	});
}
async function espnJson(url) {
	const cached = readCache(`espn:${url}`);
	if (cached) return cached;
	try {
		const res = await fetch(url, {
			headers: {
				"User-Agent": UA,
				Accept: "application/json"
			},
			signal: AbortSignal.timeout(9e3)
		});
		if (!res.ok) return null;
		const json = await res.json();
		writeCache(`espn:${url}`, json);
		return json;
	} catch {
		return null;
	}
}
function asRecord(value) {
	return value !== null && typeof value === "object" ? value : null;
}
function asArray(value) {
	return Array.isArray(value) ? value : [];
}
function str(value, fallback = "") {
	return typeof value === "string" ? value : fallback;
}
function num(value, fallback = 0) {
	if (typeof value === "number" && Number.isFinite(value)) return value;
	if (typeof value === "string") {
		const n = Number(value);
		if (Number.isFinite(n)) return n;
	}
	return fallback;
}
function statusFrom(raw) {
	const type = asRecord(asRecord(raw)?.type);
	const state = str(type?.state, "pre");
	return {
		status: state === "in" || state === "post" ? state : "pre",
		detail: str(type?.shortDetail) || str(type?.description) || "Scheduled"
	};
}
function parseOdds(competition) {
	const first = asRecord(asArray(competition.odds)[0]);
	if (!first) return null;
	const ml = asRecord(first.moneyline);
	const home = asRecord(asRecord(ml?.home)?.close) ?? asRecord(ml?.home);
	const away = asRecord(asRecord(ml?.away)?.close) ?? asRecord(ml?.away);
	const draw = asRecord(asRecord(ml?.draw)?.close) ?? asRecord(ml?.draw);
	const total = asRecord(first.total);
	const over = asRecord(asRecord(asRecord(total?.over)?.close) ?? asRecord(total?.over));
	const under = asRecord(asRecord(asRecord(total?.under)?.close) ?? asRecord(total?.under));
	const snapshot = {
		mlHome: parseAmerican(home?.odds),
		mlDraw: parseAmerican(draw?.odds),
		mlAway: parseAmerican(away?.odds),
		overUnder: num(first.overUnder, NaN),
		overOdds: parseAmerican(over?.odds),
		underOdds: parseAmerican(under?.odds),
		impliedHome: null,
		impliedDraw: null,
		impliedAway: null,
		impliedOver: null,
		impliedUnder: null
	};
	if (Number.isNaN(snapshot.overUnder)) snapshot.overUnder = null;
	if (snapshot.mlHome == null && snapshot.mlAway == null && snapshot.overUnder == null) return null;
	return impliedFromBook(snapshot);
}
function parseTeam(comp, homeAway) {
	const team = asRecord(comp.team);
	if (!team) return null;
	const rec0 = asRecord(asArray(comp.records)[0]);
	const color = str(team.color, "3f4550").replace("#", "");
	const alt = str(team.alternateColor, "d0d4da").replace("#", "");
	const logo = str(team.logo) || `https://a.espncdn.com/i/teamlogos/soccer/500/${str(team.id)}.png`;
	return {
		id: str(team.id),
		name: str(team.displayName, "Team"),
		shortName: str(team.shortDisplayName) || str(team.name) || str(team.displayName, "Team"),
		abbr: str(team.abbreviation, "FC"),
		logo,
		color,
		altColor: alt,
		form: str(comp.form).toUpperCase(),
		record: str(rec0?.summary, "0-0-0"),
		rank: null,
		gp: 0,
		gf: 0,
		ga: 0,
		pts: 0,
		homeAway,
		score: comp.score == null || comp.score === "" ? null : num(comp.score, 0)
	};
}
function parseEvent(event, leagueSlug) {
	const profile = LEAGUE_BY_SLUG[leagueSlug];
	const competition = asRecord(asArray(event.competitions)[0]) ?? event;
	asRecord(competition)?.competitors ?? event.competitions;
	const list = asArray(asRecord(competition)?.competitors);
	if (list.length < 2) return null;
	let homeRaw = null;
	let awayRaw = null;
	for (const item of list) {
		const rec = asRecord(item);
		if (!rec) continue;
		if (str(rec.homeAway) === "home") homeRaw = rec;
		if (str(rec.homeAway) === "away") awayRaw = rec;
	}
	if (!homeRaw || !awayRaw) {
		homeRaw = asRecord(list[0]);
		awayRaw = asRecord(list[1]);
	}
	if (!homeRaw || !awayRaw) return null;
	const home = parseTeam(homeRaw, "home");
	const away = parseTeam(awayRaw, "away");
	if (!home || !away) return null;
	const venue = asRecord(asRecord(competition)?.venue) ?? asRecord(event.venue);
	const address = asRecord(venue?.address);
	const { status, detail } = statusFrom(event.status ?? asRecord(competition)?.status);
	return {
		id: str(event.id),
		league: leagueSlug,
		leagueName: profile?.name ?? str(event.name, leagueSlug),
		leagueShort: profile?.short ?? leagueSlug,
		kickoff: str(event.date),
		venue: str(venue?.fullName) || null,
		city: str(address?.city) || null,
		status,
		statusDetail: detail,
		home,
		away,
		book: parseOdds(asRecord(competition) ?? {})
	};
}
function statValue(stats, name) {
	for (const item of stats) {
		const rec = asRecord(item);
		if (str(rec?.name) === name || str(rec?.abbreviation) === name) return num(rec?.value, 0);
	}
	return 0;
}
function parseStandings(json) {
	const root = asRecord(json);
	if (!root) return null;
	const children = asArray(root.children);
	const groups = children.length ? children : [root];
	const byId = {};
	let gfSum = 0;
	let gpSum = 0;
	for (const group of groups) {
		const g = asRecord(group);
		const entries = asArray(asRecord(asRecord(g?.standings)?.standings)?.entries).length ? asArray(asRecord(asRecord(g?.standings)?.standings)?.entries) : asArray(asRecord(g?.standings)?.entries);
		const fallback = entries.length ? entries : asArray(asRecord(g?.standings)?.entries);
		const list = fallback.length ? fallback : asArray(asRecord(g)?.entries);
		for (const entry of list.length ? list : entries) {
			const rec = asRecord(entry);
			if (!rec) continue;
			const id = str(asRecord(rec.team)?.id);
			if (!id) continue;
			const stats = asArray(rec.stats);
			const gp = statValue(stats, "gamesPlayed") || statValue(stats, "GP");
			const gf = statValue(stats, "pointsFor") || statValue(stats, "GF");
			const ga = statValue(stats, "pointsAgainst") || statValue(stats, "GA");
			const pts = statValue(stats, "points") || statValue(stats, "PTS");
			const rank = statValue(stats, "rank") || 0;
			gfSum += gf;
			gpSum += gp;
			byId[id] = {
				teamId: id,
				gp,
				gf,
				ga,
				pts,
				rank,
				attack: 1,
				defense: 1
			};
		}
	}
	const ids = Object.keys(byId);
	if (!ids.length) return null;
	const avgFor = gpSum > 0 ? gfSum / gpSum : 1.35;
	for (const id of ids) {
		const row = byId[id];
		const gp = Math.max(row.gp, 1);
		row.attack = row.gf / gp / Math.max(avgFor, .6);
		row.defense = row.ga / gp / Math.max(avgFor, .6);
	}
	return {
		byId,
		avgGoals: avgFor * 2
	};
}
function applyRatings(input, table) {
	if (!table) return input;
	const patch = (team) => {
		const row = table.byId[team.id];
		if (!row) return team;
		return {
			...team,
			rank: row.rank || team.rank,
			gp: row.gp || team.gp,
			gf: row.gf || team.gf,
			ga: row.ga || team.ga,
			pts: row.pts || team.pts
		};
	};
	return {
		...input,
		home: patch(input.home),
		away: patch(input.away)
	};
}
async function fetchScoreboard(slug) {
	const root = asRecord(await espnJson(`https://site.api.espn.com/apis/site/v2/sports/soccer/${slug}/scoreboard`));
	if (!root) return [];
	const events = asArray(root.events);
	const parsed = [];
	for (const event of events) {
		const rec = asRecord(event);
		if (!rec) continue;
		const item = parseEvent(rec, slug);
		if (item) parsed.push(item);
	}
	return parsed;
}
async function fetchRatings(slug) {
	if (!LEAGUE_BY_SLUG[slug]?.standings) return null;
	return parseStandings(await espnJson(`https://site.api.espn.com/apis/v2/sports/soccer/${slug}/standings`));
}
function parseRecents(json, teamId) {
	const events = asArray(asRecord(asArray(json).find((row) => str(asRecord(asRecord(row)?.team)?.id) === teamId))?.events);
	const out = [];
	for (const event of events.slice(0, 5)) {
		const rec = asRecord(event);
		if (!rec) continue;
		const opp = asRecord(rec.opponent);
		const resultRaw = str(rec.gameResult, "D").toUpperCase();
		const result = resultRaw === "W" || resultRaw === "L" ? resultRaw : "D";
		out.push({
			opponent: str(opp?.displayName, "Opponent"),
			opponentAbbr: str(opp?.abbreviation, "OPP"),
			result,
			score: str(rec.score, "–"),
			atHome: str(rec.atVs) === "vs",
			date: str(rec.gameDate),
			competition: str(rec.leagueAbbreviation) || str(rec.competitionName)
		});
	}
	return out;
}
async function fetchBoard() {
	const generatedAt = (/* @__PURE__ */ new Date()).toISOString();
	try {
		const scoreboards = await Promise.all(LEAGUES.map((league) => fetchScoreboard(league.slug)));
		const ratingList = await Promise.all(LEAGUES.map((league) => fetchRatings(league.slug)));
		const ratingsByLeague = {};
		LEAGUES.forEach((league, i) => {
			ratingsByLeague[league.slug] = ratingList[i] ?? null;
		});
		const matches = [];
		for (let i = 0; i < LEAGUES.length; i += 1) {
			const table = ratingsByLeague[LEAGUES[i].slug] ?? null;
			for (const event of scoreboards[i] ?? []) {
				if (event.status === "post") continue;
				matches.push(predictMatch(applyRatings(event, table), table));
			}
		}
		matches.sort((a, b) => {
			if (a.status === "in" && b.status !== "in") return -1;
			if (b.status === "in" && a.status !== "in") return 1;
			return new Date(a.kickoff).getTime() - new Date(b.kickoff).getTime();
		});
		return {
			generatedAt,
			matches,
			leagues: LEAGUES.map((league, i) => ({
				id: league.slug,
				name: league.name,
				short: league.short,
				count: (scoreboards[i] ?? []).filter((e) => e.status !== "post").length
			})).filter((l) => l.count > 0),
			error: matches.length ? null : "No upcoming fixtures found. Try again shortly."
		};
	} catch (err) {
		return {
			generatedAt,
			matches: [],
			leagues: [],
			error: err instanceof Error ? err.message : "Could not load fixtures."
		};
	}
}
async function fetchMatchDetail(league, eventId) {
	const found = (await fetchBoard()).matches.find((m) => m.id === eventId && m.league === league);
	const summary = await espnJson(`https://site.api.espn.com/apis/site/v2/sports/soccer/${league}/summary?event=${eventId}`);
	const recentsHome = found ? parseRecents(asRecord(summary)?.lastFiveGames, found.home.id) : [];
	const recentsAway = found ? parseRecents(asRecord(summary)?.lastFiveGames, found.away.id) : [];
	if (found) return {
		...found,
		recents: {
			home: recentsHome,
			away: recentsAway
		}
	};
	const header = asRecord(asRecord(summary)?.header);
	if (!header) return null;
	const parsed = parseEvent(header, league);
	if (!parsed) return null;
	const table = await fetchRatings(league);
	const predicted = predictMatch(applyRatings(parsed, table), table);
	return {
		...predicted,
		recents: {
			home: parseRecents(asRecord(summary)?.lastFiveGames, predicted.home.id),
			away: parseRecents(asRecord(summary)?.lastFiveGames, predicted.away.id)
		}
	};
}
//#endregion
export { fetchBoard, fetchMatchDetail };
