import { i as __toESM } from "../_runtime.mjs";
import { o as formatPct } from "./math-pGXUxFVe.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { c as Check, i as Plus, s as Layers } from "../_libs/lucide-react.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { a as useSlip, i as cn, r as Button } from "./router-ftrmobCt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/functions-CC0dpPUj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AppHeader() {
	const count = useSlip((s) => s.legs.length);
	const setOpen = useSlip((s) => s.setOpen);
	const [ready, setReady] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setReady(true), []);
	const shown = ready ? count : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "sticky top-0 z-40 border-b border-border bg-background/85 backdrop-blur-sm",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/",
				className: "flex items-center gap-3 outline-none focus-visible:ring-2 focus-visible:ring-ring/70",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "relative flex size-8 items-center justify-center rounded-md border border-border",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-1.5 h-px w-4 bg-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-2 size-1.5 rounded-full bg-foreground" })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex flex-col leading-none",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-xl tracking-tight",
						children: "Crossbar"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs tracking-[0.18em] text-muted-foreground uppercase",
						children: "Markets desk"
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				size: "sm",
				onClick: () => setOpen(true),
				className: "min-w-11",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, {}),
					"Slip",
					shown > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full bg-primary px-1.5 text-xs text-primary-foreground tabular-nums",
						children: shown
					}) : null
				]
			})]
		})
	});
}
function FormRow({ form }) {
	const chars = form.replace(/[^WDL]/gi, "").slice(0, 5).split("");
	if (!chars.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "inline-flex items-center gap-0.5",
		"aria-label": `Form ${chars.join(" ")}`,
		children: chars.map((char, i) => {
			const c = char.toUpperCase();
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("inline-flex size-4 items-center justify-center rounded-xs text-[9px] font-semibold", c === "W" && "bg-lean/20 text-lean", c === "D" && "bg-secondary text-muted-foreground", c === "L" && "bg-live/15 text-live"),
				children: c
			}, `${c}-${i}`);
		})
	});
}
function MarketChip({ match, pick, compact = false }) {
	const add = useSlip((s) => s.add);
	const onSlip = useSlip((s) => s.legs).some((leg) => leg.matchId === match.id && leg.marketKey === pick.key);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex items-center gap-2 rounded-md border border-border bg-background/60 px-2.5 py-2", compact && "flex-col items-stretch gap-1 px-2 py-1.5"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate text-[10px] tracking-wide text-muted-foreground uppercase",
				children: pick.title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate text-sm font-medium text-foreground",
				children: pick.pick
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "tabular-nums text-sm text-lean",
				children: formatPct(pick.probability)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": onSlip ? "On slip" : `Add ${pick.pick}`,
				onClick: (e) => {
					e.preventDefault();
					e.stopPropagation();
					add(match, pick);
				},
				className: cn("inline-flex size-8 items-center justify-center rounded-sm border border-border text-muted-foreground transition-colors hover:text-foreground", onSlip && "border-lean/40 bg-lean/10 text-lean"),
				children: onSlip ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" })
			})]
		})]
	});
}
function TeamCrest({ src, name, color, size = "md" }) {
	const [failed, setFailed] = (0, import_react.useState)(false);
	const dim = size === "lg" ? "size-14" : size === "sm" ? "size-8" : "size-11";
	if (failed) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex shrink-0 items-center justify-center rounded-full text-[10px] font-semibold tracking-wide text-foreground", dim),
		style: { backgroundColor: `#${color || "3f4550"}` },
		"aria-hidden": true,
		children: name.slice(0, 2).toUpperCase()
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src,
		alt: "",
		width: 56,
		height: 56,
		loading: "lazy",
		onError: () => setFailed(true),
		className: cn("shrink-0 object-contain", dim)
	});
}
var badgeVariants = cva("inline-flex items-center rounded-full border px-2.5 py-0.5 text-[11px] font-medium tracking-wide uppercase", {
	variants: { variant: {
		default: "border-transparent bg-secondary text-muted-foreground",
		live: "border-transparent bg-live/15 text-live",
		lean: "border-transparent bg-lean/15 text-lean",
		outline: "border-border text-muted-foreground"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
function Skeleton({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: cn("animate-pulse rounded-md bg-muted", className) });
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var loadBoard = createServerFn({ method: "POST" }).handler(createSsrRpc("88b49dbf07ad1a40a3c37974e3313023e153ef9c40065613e95d55e3f1e6d493"));
var loadMatch = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("1237394747655ae56cc41085e60ee1eae84d0fe7a47b92e83203e1ba51fcc393"));
var briefMatch = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("72542244dee4bc3a1cf9faba907d7aa32347f54f3138863651f815fdc275a448"));
//#endregion
export { Skeleton as a, loadBoard as c, MarketChip as i, loadMatch as l, Badge as n, TeamCrest as o, FormRow as r, briefMatch as s, AppHeader as t };
