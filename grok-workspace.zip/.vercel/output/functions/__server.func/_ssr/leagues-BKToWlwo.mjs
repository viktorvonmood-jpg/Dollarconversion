//#region node_modules/.nitro/vite/services/ssr/assets/leagues-BKToWlwo.js
var LEAGUES = [
	{
		slug: "eng.1",
		name: "Premier League",
		short: "EPL",
		avgGoals: 2.86,
		homeShare: .55,
		homeAdv: 1.12,
		avgCorners: 10.6,
		avgCards: 4.15,
		avgSot: 9.5,
		avgWoodwork: .58,
		standings: true
	},
	{
		slug: "esp.1",
		name: "La Liga",
		short: "LAL",
		avgGoals: 2.62,
		homeShare: .56,
		homeAdv: 1.16,
		avgCorners: 9.7,
		avgCards: 5.05,
		avgSot: 9,
		avgWoodwork: .52,
		standings: true
	},
	{
		slug: "ger.1",
		name: "Bundesliga",
		short: "BUN",
		avgGoals: 3.12,
		homeShare: .55,
		homeAdv: 1.13,
		avgCorners: 10.3,
		avgCards: 3.85,
		avgSot: 10.2,
		avgWoodwork: .64,
		standings: true
	},
	{
		slug: "ita.1",
		name: "Serie A",
		short: "SEA",
		avgGoals: 2.58,
		homeShare: .54,
		homeAdv: 1.14,
		avgCorners: 9.6,
		avgCards: 4.7,
		avgSot: 8.9,
		avgWoodwork: .5,
		standings: true
	},
	{
		slug: "fra.1",
		name: "Ligue 1",
		short: "FL1",
		avgGoals: 2.68,
		homeShare: .55,
		homeAdv: 1.15,
		avgCorners: 9.4,
		avgCards: 3.9,
		avgSot: 9.1,
		avgWoodwork: .53,
		standings: true
	},
	{
		slug: "uefa.champions",
		name: "Champions League",
		short: "UCL",
		avgGoals: 2.92,
		homeShare: .54,
		homeAdv: 1.1,
		avgCorners: 10.1,
		avgCards: 4.2,
		avgSot: 9.6,
		avgWoodwork: .57,
		standings: true
	},
	{
		slug: "uefa.europa",
		name: "Europa League",
		short: "UEL",
		avgGoals: 2.78,
		homeShare: .54,
		homeAdv: 1.1,
		avgCorners: 9.9,
		avgCards: 4.35,
		avgSot: 9.3,
		avgWoodwork: .54,
		standings: true
	},
	{
		slug: "eng.2",
		name: "Championship",
		short: "CHA",
		avgGoals: 2.64,
		homeShare: .56,
		homeAdv: 1.14,
		avgCorners: 10.5,
		avgCards: 4.35,
		avgSot: 9.2,
		avgWoodwork: .55,
		standings: true
	},
	{
		slug: "ned.1",
		name: "Eredivisie",
		short: "ERE",
		avgGoals: 3.18,
		homeShare: .56,
		homeAdv: 1.14,
		avgCorners: 10.8,
		avgCards: 3.7,
		avgSot: 10.6,
		avgWoodwork: .66,
		standings: true
	},
	{
		slug: "por.1",
		name: "Primeira Liga",
		short: "POR",
		avgGoals: 2.72,
		homeShare: .55,
		homeAdv: 1.15,
		avgCorners: 10,
		avgCards: 5.1,
		avgSot: 9.2,
		avgWoodwork: .51,
		standings: true
	},
	{
		slug: "sco.1",
		name: "Scottish Premiership",
		short: "SPL",
		avgGoals: 2.7,
		homeShare: .56,
		homeAdv: 1.16,
		avgCorners: 10.2,
		avgCards: 4,
		avgSot: 9.1,
		avgWoodwork: .52,
		standings: true
	},
	{
		slug: "tur.1",
		name: "Süper Lig",
		short: "TUR",
		avgGoals: 2.84,
		homeShare: .57,
		homeAdv: 1.18,
		avgCorners: 9.8,
		avgCards: 5.15,
		avgSot: 9.4,
		avgWoodwork: .5,
		standings: true
	},
	{
		slug: "usa.1",
		name: "MLS",
		short: "MLS",
		avgGoals: 2.9,
		homeShare: .57,
		homeAdv: 1.18,
		avgCorners: 10.2,
		avgCards: 4.45,
		avgSot: 9.6,
		avgWoodwork: .55,
		standings: true
	},
	{
		slug: "bra.1",
		name: "Brasileirão",
		short: "BRA",
		avgGoals: 2.48,
		homeShare: .57,
		homeAdv: 1.2,
		avgCorners: 10.7,
		avgCards: 5.35,
		avgSot: 9,
		avgWoodwork: .48,
		standings: true
	},
	{
		slug: "mex.1",
		name: "Liga MX",
		short: "MEX",
		avgGoals: 2.74,
		homeShare: .56,
		homeAdv: 1.16,
		avgCorners: 9.9,
		avgCards: 4.9,
		avgSot: 9.2,
		avgWoodwork: .51,
		standings: true
	}
];
var LEAGUE_BY_SLUG = Object.fromEntries(LEAGUES.map((league) => [league.slug, league]));
var MARKET_META = [
	{
		key: "double_chance",
		label: "Double chance",
		short: "DC"
	},
	{
		key: "over_15",
		label: "Over 1.5 goals",
		short: "O1.5"
	},
	{
		key: "over_25",
		label: "Over 2.5 / 2.6",
		short: "O2.6"
	},
	{
		key: "corners",
		label: "Total corners",
		short: "Corners"
	},
	{
		key: "cards",
		label: "Total cards",
		short: "Cards"
	},
	{
		key: "sot",
		label: "Shots on target",
		short: "SOT"
	},
	{
		key: "woodwork",
		label: "Hitting the crossbar",
		short: "Crossbar"
	}
];
//#endregion
export { LEAGUE_BY_SLUG as n, MARKET_META as r, LEAGUES as t };
