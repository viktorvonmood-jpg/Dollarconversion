import { i as __toESM } from "../_runtime.mjs";
import { r as MARKET_META } from "./leagues-BKToWlwo.mjs";
import { a as formatKickoff, o as formatPct, s as leanScore } from "./math-pGXUxFVe.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { o as MapPin } from "../_libs/lucide-react.mjs";
import { n as useQuery } from "../_libs/tanstack__react-query.mjs";
import { a as useSlip, i as cn, r as Button } from "./router-ftrmobCt.mjs";
import { a as Skeleton, c as loadBoard, i as MarketChip, n as Badge, o as TeamCrest, r as FormRow, t as AppHeader } from "./functions-CC0dpPUj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CuBeNiHi.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MatchCard({ match, delay = 0 }) {
	const when = formatKickoff(match.kickoff);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "stagger-in rounded-xl border border-border bg-card p-4 shadow-[var(--shadow-card)] sm:p-5",
		style: { animationDelay: `${delay}ms` },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-4 flex items-center justify-between gap-3 text-[11px] tracking-wide text-muted-foreground uppercase",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-foreground/80",
							children: match.leagueShort
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": true,
							children: "·"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							when.day,
							" ",
							when.time
						] })
					]
				}), match.status === "in" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: "live",
					children: "Live"
				}) : null]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/match/$league/$eventId",
				params: {
					league: match.league,
					eventId: match.id
				},
				className: "grid grid-cols-[1fr_auto_1fr] items-center gap-3 rounded-lg outline-none focus-visible:ring-2 focus-visible:ring-ring/70",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamBlock, {
						team: match.home,
						align: "left",
						liveScore: match.status === "in" ? match.home.score : null
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[11px] tracking-[0.2em] text-muted-foreground uppercase",
						children: "v"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamBlock, {
						team: match.away,
						align: "right",
						liveScore: match.status === "in" ? match.away.score : null
					})
				]
			}),
			match.venue ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 flex items-center gap-1.5 text-xs text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3" }),
					match.venue,
					match.city ? ` · ${match.city}` : ""
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 rounded-md border border-border bg-background/50 px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[10px] tracking-wide text-muted-foreground uppercase",
					children: "Top lean"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "flex items-baseline justify-between gap-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: match.topPick.pick
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums text-lean",
						children: formatPct(match.topPick.probability)
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2",
				children: match.markets.map((pick) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketChip, {
					match,
					pick
				}, pick.key))
			})
		]
	});
}
function TeamBlock({ team, align, liveScore }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: align === "right" ? "flex flex-row-reverse items-center gap-2" : "flex items-center gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeamCrest, {
			src: team.logo,
			name: team.abbr,
			color: team.color
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: align === "right" ? "min-w-0 text-right" : "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate font-medium",
				children: team.shortName
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: align === "right" ? "mt-0.5 flex flex-row-reverse items-center gap-2" : "mt-0.5 flex items-center gap-2",
				children: [liveScore != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "tabular-nums text-lg leading-none",
					children: liveScore
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-[11px] text-muted-foreground tabular-nums",
					children: team.record
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormRow, { form: team.form })]
			})]
		})]
	});
}
function Home() {
	const board = useQuery({
		queryKey: ["board"],
		queryFn: () => loadBoard()
	});
	const [league, setLeague] = (0, import_react.useState)("all");
	const [market, setMarket] = (0, import_react.useState)("all");
	const [view, setView] = (0, import_react.useState)("board");
	const matches = board.data?.matches ?? [];
	const filtered = (0, import_react.useMemo)(() => {
		return matches.filter((m) => league === "all" ? true : m.league === league);
	}, [matches, league]);
	const grouped = (0, import_react.useMemo)(() => {
		const map = /* @__PURE__ */ new Map();
		for (const match of filtered) {
			const group = formatKickoff(match.kickoff).group;
			const list = map.get(group) ?? [];
			list.push(match);
			map.set(group, list);
		}
		return [...map.entries()];
	}, [filtered]);
	const pulse = (0, import_react.useMemo)(() => {
		const rows = [];
		for (const match of filtered) {
			const best = [...market === "all" ? match.markets : match.markets.filter((p) => p.key === market)].sort((a, b) => leanScore(b.key, b.probability, b.confidence, b.edge) - leanScore(a.key, a.probability, a.confidence, a.edge))[0];
			if (best) rows.push({
				match,
				key: best.key
			});
		}
		rows.sort((a, b) => {
			const pa = a.match.markets.find((m) => m.key === a.key);
			const pb = b.match.markets.find((m) => m.key === b.key);
			return leanScore(pb.key, pb.probability, pb.confidence, pb.edge) - leanScore(pa.key, pa.probability, pa.confidence, pa.edge);
		});
		return rows.slice(0, 20);
	}, [filtered, market]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppHeader, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto max-w-6xl px-4 pb-24 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "relative overflow-hidden pt-8 pb-6 sm:pt-12",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pitch-grid pointer-events-none absolute inset-0 opacity-40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] tracking-[0.22em] text-muted-foreground uppercase",
								children: "Live fixtures · model desk"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "mt-2 max-w-2xl font-display text-4xl leading-[1.05] tracking-tight sm:text-5xl",
								children: "Football markets, priced from the table and the tape."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 max-w-xl text-sm leading-relaxed text-muted-foreground sm:text-base",
								children: "Double chance, Over 1.5, Over 2.5 / 2.6 (three goals or more), total corners, total cards, shots on target, and hitting the crossbar. Poisson goals plus league priors — not a tipster shout."
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sticky top-16 z-30 -mx-4 mb-6 border-y border-border bg-background/90 px-4 py-3 backdrop-blur-sm sm:mx-0 sm:rounded-lg sm:border sm:px-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterButton, {
									active: view === "board",
									onClick: () => setView("board"),
									children: "Board"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterButton, {
									active: view === "pulse",
									onClick: () => setView("pulse"),
									children: "Strong leans"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ChipRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterButton, {
								active: league === "all",
								onClick: () => setLeague("all"),
								children: "All leagues"
							}), (board.data?.leagues ?? []).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FilterButton, {
								active: league === item.id,
								onClick: () => setLeague(item.id),
								children: [item.short, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "tabular-nums text-muted-foreground",
									children: item.count
								})]
							}, item.id))] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ChipRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterButton, {
								active: market === "all",
								onClick: () => setMarket("all"),
								children: "All markets"
							}), MARKET_META.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterButton, {
								active: market === item.key,
								onClick: () => setMarket(item.key),
								children: item.short
							}, item.key))] })
						]
					})
				}),
				board.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoardSkeleton, {}) : null,
				board.data?.error && !matches.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-border bg-card p-8 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-2xl",
							children: "No board yet"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: board.data.error
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "mt-4",
							onClick: () => board.refetch(),
							children: "Retry"
						})
					]
				}) : null,
				view === "board" && grouped.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col gap-10",
					children: grouped.map(([label, list]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mb-4 font-display text-2xl tracking-tight",
						children: label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-4 lg:grid-cols-2",
						children: list.map((match, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketFilteredCard, {
							match,
							market,
							delay: Math.min(i, 8) * 40
						}, `${match.league}-${match.id}`))
					})] }, label))
				}) : null,
				view === "pulse" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PulseList, { rows: pulse }) : null,
				!board.isLoading && !filtered.length && !board.data?.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-16 text-center text-sm text-muted-foreground",
					children: "No fixtures in this filter."
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
					className: "mt-16 border-t border-border py-8 text-xs leading-relaxed text-muted-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Crossbar is a statistical desk, not a bookmaker. Expected goals use a Poisson model from standings, form and league scoring rates. Corners, cards, shots and woodwork are count models around those league priors. Predictions are for information only — never stake more than you can afford to lose." })
				})
			]
		})]
	});
}
function MarketFilteredCard({ match, market, delay }) {
	if (market === "all") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchCard, {
		match,
		delay
	});
	const narrowed = {
		...match,
		markets: match.markets.filter((p) => p.key === market),
		topPick: match.markets.find((p) => p.key === market) ?? match.topPick
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchCard, {
		match: narrowed,
		delay
	});
}
function PulseList({ rows }) {
	const add = useSlip((s) => s.add);
	if (!rows.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "py-16 text-center text-sm text-muted-foreground",
		children: "No high-confidence leans in this cut. Open the board or widen the filter."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-hidden rounded-xl border border-border",
		children: rows.map(({ match, key }) => {
			const pick = match.markets.find((m) => m.key === key);
			if (!pick) return null;
			const when = formatKickoff(match.kickoff);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 border-b border-border px-4 py-3 last:border-b-0 sm:flex-row sm:items-center sm:gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-[11px] tracking-wide text-muted-foreground uppercase",
							children: [
								match.leagueShort,
								" · ",
								when.day,
								" ",
								when.time
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "truncate font-medium",
							children: [
								match.home.shortName,
								" v ",
								match.away.shortName
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-w-0 flex-1 items-center justify-between gap-3 sm:max-w-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] text-muted-foreground uppercase",
								children: pick.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-sm",
								children: pick.pick
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "lean",
							className: "tabular-nums",
							children: formatPct(pick.probability)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						onClick: () => add(match, pick),
						children: "Add"
					})
				]
			}, `${match.id}-${key}`);
		})
	});
}
function ChipRow({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex gap-2 overflow-x-auto pb-1 sm:flex-wrap sm:overflow-visible [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden",
		children
	});
}
function FilterButton({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: cn("inline-flex h-10 shrink-0 items-center gap-1.5 rounded-full border px-3 text-xs font-medium transition-colors", active ? "border-primary bg-primary text-primary-foreground" : "border-border bg-transparent text-muted-foreground hover:text-foreground"),
		children
	});
}
function BoardSkeleton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-4 lg:grid-cols-2",
		children: Array.from({ length: 6 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl border border-border bg-card p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-3 w-32" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex items-center justify-between",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "size-11 rounded-full" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-16" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "size-11 rounded-full" })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "mt-6 h-16 w-full" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 grid grid-cols-2 gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-14" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-14" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-14" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-14" })
					]
				})
			]
		}, i))
	});
}
//#endregion
export { Home as component };
