//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Cbq-6iDf.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/match/$league/$eventId"],
		preloads: ["/assets/index-DPEMFwnC.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DPEMFwnC.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CO89aniD.js", "/assets/functions-Z5D0KZ_m.js"]
	},
	"/match/$league/$eventId": {
		filePath: "/workspace/src/routes/match.$league.$eventId.tsx",
		children: void 0,
		preloads: ["/assets/match._league._eventId-BktNnM-8.js", "/assets/functions-Z5D0KZ_m.js"]
	}
} });
//#endregion
export { tsrStartManifest };
